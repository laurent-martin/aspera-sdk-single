# Grpc generated classes are assumed to be in the load path
$LOAD_PATH << '.'

require 'json'
require 'transfer_services_pb'

include Transfersdk

def main
  # create a connection to the transfer manager daemon
  client = TransferService::Stub.new('localhost:55002',
                                     :this_channel_is_insecure)

  # create transfer spec string
  transfer_spec = {
    session_initiation: {
      ssh: {
        ssh_port: 33001,
        remote_user: 'aspera',
        remote_password: 'demoaspera'
      }
    },
    remote_host: 'demo.asperasoft.com'
  }.to_json

  peer_check_request = PeerCheckRequest.new(transferSpec: transfer_spec)
  peer_check_response = client.is_peer_reachable(peer_check_request)
  puts "peer check response #{peer_check_response}"
end

# program entry point
main if __FILE__ == $PROGRAM_NAME
