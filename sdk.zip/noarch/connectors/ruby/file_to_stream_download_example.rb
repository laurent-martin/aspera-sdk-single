# Grpc generated classes are assumed to be in the load path
$LOAD_PATH << '.'

require 'transfer_services_pb'
require 'json'

include Transfersdk

def main
  # create a connection to the faspmanager daemon
  client = TransferService::Stub.new('localhost:55002',
                                     :this_channel_is_insecure)

  # create transfer spec string
  transfer_spec = {
    session_initiation: {
      ssh: {
        ssh_port: 33001,
        remote_user: 'aspera',
        remote_password: 'demoaspera'
      }
    },
    direction: 'recv',
    remote_host: 'demo.asperasoft.com',
    file_system: {
      # file to stream downloads require an overwrite option
      overwrite: 'always'
    },
    assets: {
      paths: [
        {
          source: 'aspera-test-dir-small/10MB.1'
        },
        {
          source: 'aspera-test-dir-tiny/200KB.2'
        },
        {
          source: 'aspera-test-dir-tiny/200KB.3'
        }
      ]
    }
  }.to_json
  puts transfer_spec

  # create a transfer request
  transfer_request = TransferRequest.new(
    transferType: TransferType::FILE_TO_STREAM_DOWNLOAD, # transfer type (file/stream)
    config: TransferConfig.new, # transfer configuration
    transferSpec: transfer_spec) # transfer definition

  # send start transfer request to the faspmanager daemon
  start_transfer_response = client.start_transfer(transfer_request)
  transfer_id = start_transfer_response.transferId
  puts "transfer started with id #{transfer_id}"

  # read data stream from transfer
  read_stream_request = ReadStreamRequest.new(transferId: transfer_id)

  client.read_stream(read_stream_request) do |apiVersion, path, pathSize,
    chunk, error|
    puts "api version #{apiVersion}, path #{path}, path size #{pathSize}, chunk content size #{chunk&.contents == nil}, error #{error}"
  end

  # stop the transfer
  client.stop_transfer(StopTransferRequest.new(transferId: [transfer_id]))

  puts 'finished'
end

# program entry point
main if __FILE__ == $PROGRAM_NAME
