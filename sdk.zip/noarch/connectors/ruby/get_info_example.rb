# Grpc generated classes are assumed to be in the load path
$LOAD_PATH << '.'

require 'transfer_services_pb'
require 'json'

include Transfersdk

# create a connection to the faspmanager daemon
client = TransferService::Stub.new('localhost:55002', :this_channel_is_insecure)

# (optional) check that the daemon is responding (get information about the daemon environment)
get_info_request = InstanceInfoRequest.new
get_info_response = client.get_info(get_info_request)
puts "instance info #{get_info_response.to_json}"

