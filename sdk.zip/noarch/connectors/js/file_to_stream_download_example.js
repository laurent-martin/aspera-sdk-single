const protoLoader = require('@grpc/proto-loader');
const grpc = require('@grpc/grpc-js')

// load definition for the aspera transfer sdk package
const packageDefinition = protoLoader.loadSync(
    'transfer.proto',
    {
        keepCase: true,
        longs: String,
        enums: String,
        defaults: true,
        oneofs: true
    });
const transfersdk = grpc.loadPackageDefinition(packageDefinition).transfersdk;

// create a connection to the transfer manager daemon
let client = new transfersdk.TransferService('localhost:55002',
    grpc.credentials.createInsecure());

// create transfer spec string
const transferSpec = {
    session_initiation: {
        ssh: {
            ssh_port: 33001,
            remote_user: 'aspera',
            remote_password: 'demoaspera'
        }
    },
    direction: 'recv',
    file_system: {
        // file to stream downloads require an overwrite option
        overwrite: 'always'
    },
    remote_host: 'demo.asperasoft.com',
    assets: {
        paths: [
            {
                source: 'aspera-test-dir-small/10MB.1'
            },
            {
                source: 'aspera-test-dir-tiny/200KB.2'
            },
            {
                source: 'aspera-test-dir-tiny/200KB.3'
            }
        ]
    }
}

let startTransferRequest = {
    transferType: 'FILE_TO_STREAM_DOWNLOAD',
    config: {},
    transferSpec: JSON.stringify(transferSpec)
}

let transferId;
let startTransferResponse = client.startTransfer(
    startTransferRequest,
    function (err, result) {
    if (err) {
        console.log("error starting transfer " + err)
    } else {
        transferId = result.transferId
        console.log("transfer started " + transferId)

        // read data stream from transfer
        let readStream = client.readStream({transferId: transferId})
        readStream.on('data', function (data) {
            console.log(data)
        })
    }
})
