package client;

import ibm.aspera.transferservice.Transfer;
import ibm.aspera.transferservice.TransferServiceGrpc;
import io.grpc.ManagedChannelBuilder;

public class IsPeerReachableExample {

    public static void main(String... args) {
        // create a connection to the transfer sdk daemon
        TransferServiceGrpc.TransferServiceBlockingStub client = TransferServiceGrpc.newBlockingStub(
                ManagedChannelBuilder.forAddress("localhost", 55002).usePlaintext().build());

        String transferSpec = "{" +
                "  \"session_initiation\": {" +
                "    \"ssh\": {" +
                "      \"ssh_port\": 33001," +
                "      \"remote_user\": \"aspera\"," +
                "      \"remote_password\": \"demoaspera\"" +
                "    }" +
                "  }," +
                "  \"remote_host\":\"demo.asperasoft.com\"" +
                "}";

        Transfer.PeerCheckResponse peerCheckResponse = client.isPeerReachable(Transfer.PeerCheckRequest.newBuilder()
                .setTransferSpec(transferSpec)
                .build());
        System.out.println("peer check response " + peerCheckResponse);
    }
}
