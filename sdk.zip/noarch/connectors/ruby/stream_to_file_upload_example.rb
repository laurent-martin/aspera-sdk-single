# Grpc generated classes are assumed to be in the load path
$LOAD_PATH << '.'

require 'transfer_services_pb'
require 'json'

include Transfersdk

def main
  # create a connection to the faspmanager daemon
  client = TransferService::Stub.new('localhost:55002',
                                     :this_channel_is_insecure)

  transfer_spec = {
    session_initiation: {
      ssh: {
        ssh_port: 33001,
        remote_user: 'aspera',
        remote_password: 'demoaspera'
      }
    },
    direction: 'send',
    remote_host: 'demo.asperasoft.com',
    assets: {
      destination_root: '/Upload'
    }
  }.to_json

  # create a transfer request
  transfer_request = TransferRequest.new(
    transferType: TransferType::STREAM_TO_FILE_UPLOAD, # transfer type (file/stream)
    config: TransferConfig.new, # transfer configuration
    transferSpec: transfer_spec) # transfer definition

  # send start transfer request to the faspmanager daemon
  start_transfer_response = client.start_transfer(transfer_request)
  transfer_id = start_transfer_response.transferId
  puts "transfer started with id #{transfer_id}"

  # total (known size) of stream upload
  size = 42

  # iterable data
  iterable_data = Enumerator.new do |y|
    contents = 'Hello World!'
    bytes_written = 0

    # write bytes
    while bytes_written < size
      # make appropriate buffer size
      content_buffer = if size - bytes_written < contents.size
                         # the last few bytes
                         bytes_left = size - bytes_written
                         contents[0...bytes_left] # subsection of bytes
                       else
                         # max buffer size
                         contents
                       end

      # yield the next item
      y << WriteStreamRequest.new(
        transferId: transfer_id,
        path: 'file',
        size: size,
        chunk: Chunk.new(contents: content_buffer))

      bytes_written += content_buffer.size
    end
  end

  # write data stream to transfer
  basic_response = client.write_stream(iterable_data)
  puts "write stream response #{basic_response}"

  client.monitor_transfers(
    RegistrationRequest.new(
      filters: [
        RegistrationFilter.new(
          operator: RegistrationFilterOperator::OR,
          transferId: [transfer_id]
        )
      ]
    )
  ) do |result|
    puts "transfer result #{result}"

    break if [:SESSION_ERROR, :ARG_STOP].include?(result.transferEvent)
  end

  # daemon won't exit unless the following StopTransfer
  # request is made for the specified transfer stream
  client.stop_transfer(StopTransferRequest.new(transferId: [transfer_id]))
end

# program entry point
main if __FILE__ == $PROGRAM_NAME
