package client;

import ibm.aspera.transferservice.Transfer;
import ibm.aspera.transferservice.TransferServiceGrpc;
import io.grpc.ManagedChannelBuilder;

public class GetApiVersionExample {

    public static void main(String... args) {
        // create a connection to the transfer sdk daemon
        TransferServiceGrpc.TransferServiceBlockingStub client = TransferServiceGrpc.newBlockingStub(
                ManagedChannelBuilder.forAddress("localhost", 55002).usePlaintext().build());

        // create a get api version request
        Transfer.APIVersionResponse apiVersionResponse = client.getAPIVersion(Transfer.APIVersionRequest.newBuilder().build());
        System.out.println(String.format("supported api versions %s", apiVersionResponse));
    }
}
