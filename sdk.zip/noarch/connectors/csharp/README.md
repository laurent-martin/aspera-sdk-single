#Aspera Transfer SDK - C# Examples

Aspera Transfer SDK Library Files

    TransferService/Transfer.cs
    TransferService/TransferGrpc.cs

### Requirements
- netstandard2.1 (grpc required version)
- netcoreapp3.1 (netstandard2.1 compatible)

### Build
- Open in Visual Studio
- Build project

### Run
- In a separate window, start the transfer sdk daemon

      # from the aspera transfer sdk installation directory
      ./bin/asperatransferd

- Select and run the desired example
