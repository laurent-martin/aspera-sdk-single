package client;

import ibm.aspera.transferservice.Transfer;
import ibm.aspera.transferservice.TransferServiceGrpc;
import io.grpc.ManagedChannelBuilder;

import java.util.Iterator;

public class FileRegularDownloadExample {

    public static void main(String... args) {
        // create a connection to the transfer sdk daemon
        TransferServiceGrpc.TransferServiceBlockingStub client = TransferServiceGrpc.newBlockingStub(
                ManagedChannelBuilder.forAddress("localhost", 55002).usePlaintext().build());

        // create transfer spec string
        String transferSpec = "{" +
                "  \"session_initiation\": {" +
                "    \"ssh\": {" +
                "      \"ssh_port\": 33001," +
                "      \"remote_user\": \"aspera\"," +
                "      \"remote_password\": \"demoaspera\"" +
                "    }" +
                "  }," +
                "  \"direction\": \"recv\"," +
                "  \"remote_host\": \"demo.asperasoft.com\"," +
                "  \"title\": \"strategic\"," +
                "  \"assets\": {" +
                "    \"destination_root\": \"" + System.getProperty("user.dir") + "\"," +
                "    \"paths\": [" +
                "      {" +
                "        \"source\": \"/aspera-test-dir-tiny/200KB.1\"," +
                "        \"destination\": \"downloaded_file\"" +
                "      }" +
                "    ]" +
                "  }" +
                "}";

        // send start transfer request to transfer sdk daemon
        Transfer.StartTransferResponse transferResponse = client.startTransfer(Transfer.TransferRequest.newBuilder()
                .setTransferType(Transfer.TransferType.FILE_REGULAR)
                .setConfig(Transfer.TransferConfig.newBuilder().build())
                .setTransferSpec(transferSpec)
                .build());
        String transferId = transferResponse.getTransferId();
        System.out.println(String.format("transfer started with id %s", transferId));

        Iterator<Transfer.TransferResponse> monitorTransferResponse = client.monitorTransfers(
                Transfer.RegistrationRequest.newBuilder()
                        .addFilters(Transfer.RegistrationFilter.newBuilder()
                                .setOperator(Transfer.RegistrationFilterOperator.OR)
                                .addTransferId(transferId)
                                .build())
                        .build());

        // monitor transfer until it finishes
        while (monitorTransferResponse.hasNext()) {
            Transfer.TransferResponse info = monitorTransferResponse.next();
            System.out.println("transfer info " + info);
            System.out.println("file info " + info.getFileInfo());
            System.out.println("transfer event " + info.getTransferEvent());

            if (info.getStatus() == Transfer.TransferStatus.FAILED ||
                    info.getStatus() == Transfer.TransferStatus.COMPLETED ||
                    info.getTransferEvent() == Transfer.TransferEvent.FILE_STOP) {
                System.out.println("upload finished " + info.getStatus().toString());
                break;
            }
        }
    }
}
