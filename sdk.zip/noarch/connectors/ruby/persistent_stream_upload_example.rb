# Grpc generated classes are assumed to be in the load path
$LOAD_PATH << '.'

require 'transfer_services_pb'
require 'json'

include Transfersdk

def main
  # create a connection to the faspmanager daemon
  client = TransferService::Stub.new('localhost:55002',
                                     :this_channel_is_insecure)

  # the exact size of the chunks we are streaming
  chunk_size = 4096

  transfer_spec = {
    session_initiation: {
      ssh: {
        ssh_port: 33001,
        remote_user: 'aspera',
        remote_password: 'demoaspera'
      }
    },
    direction: 'send',
    remote_host: 'demo.asperasoft.com',
    assets: {
      destination_root: '/Upload'
    },
    transport: {
      streaming: {
        chunk_size: chunk_size,
        compression: {
          method: 'zlib',
          hint: '4'
        }
      }
    }
  }.to_json

  # create a transfer request
  transfer_request = TransferRequest.new(
    transferType: TransferType::PERSISTENT_STREAM_UPLOAD, # transfer type (file/stream)
    config: TransferConfig.new, # transfer configuration
    transferSpec: transfer_spec) # transfer definition

  # send start transfer request to the faspmanager daemon
  start_transfer_response = client.start_transfer(transfer_request)
  transfer_id = start_transfer_response.transferId
  puts "transfer started with id #{transfer_id}"

  # iterable data
  iterable_data = Enumerator.new do |y|
    contents = 'a' * chunk_size # contents of each stream chunk must be exactly equal to chunk size

    # total (known size) of stream upload
    size = contents.size * 3

    # offset for write start (for specifying write chunk start, possible overwrite)
    offset = 0

    # write bytes
    bytes_written = 0
    while bytes_written < size
      # make appropriate buffer size
      content_buffer = if size - bytes_written < contents.size
                         # the last few bytes
                         bytes_left = size - bytes_written
                         contents[0...bytes_left] # subsection of bytes
                       else
                         # max buffer size
                         contents
                       end

      # yield the next item
      y << WriteStreamChunkRequest.new(
        transferId: transfer_id,
        path: 'file',
        range: TransferRange.new(offset: offset, length: content_buffer.size),
        chunk: Chunk.new(contents: content_buffer))

      offset += chunk_size # offset must be an integer multiple of chunk size
      bytes_written += content_buffer.size
    end
  end

  # write data stream to transfer
  basic_response = client.write_stream_chunk(iterable_data)
  puts "write stream response #{basic_response}"

  # data has transferred, stop the stream
  client.stop_transfer(StopTransferRequest.new(transferId: [transfer_id]))

  client.monitor_transfers(
    RegistrationRequest.new(
      transferId: [transfer_id],
      filters: [
        RegistrationFilter.new(operator: RegistrationFilterOperator::OR)
      ]
    )
  ) do |result|
    puts "transfer result #{result}"

    break if [:SESSION_STOP, :FILE_ERROR, :SESSION_ERROR].include?(
      result.transferEvent)
  end
end

# program entry point
main if __FILE__ == $PROGRAM_NAME
