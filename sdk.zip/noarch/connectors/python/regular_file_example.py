import grpc
import json
import os.path

import transfer_pb2 as transfer_manager
import transfer_pb2_grpc as transfer_manager_grpc


def run():
    # create a connection to the transfer manager daemon
    client = transfer_manager_grpc.TransferServiceStub(grpc.insecure_channel('localhost:55002'))

    # create file
    file_path = generate_source_file()

    # create transfer spec
    transfer_spec = {
        "session_initiation": {
            "ssh": {
                "ssh_port": 33001,
                "remote_user": "aspera",
                "remote_password": "demoaspera"
            }
        },
        "direction": "send",
        "remote_host": "demo.asperasoft.com",
        "title": "strategic",
        "assets": {
            "destination_root": "/Upload",
            "paths": [
                {
                    "source": file_path
                }
            ]
        }
    }
    transfer_spec = json.dumps(transfer_spec)

    # create a transfer request
    transfer_request = transfer_manager.TransferRequest(
        transferType=transfer_manager.FILE_REGULAR,
        config=transfer_manager.TransferConfig(),
        transferSpec=transfer_spec)

    # send start transfer request to transfer manager daemon
    transfer_response = client.StartTransfer(transfer_request)
    transfer_id = transfer_response.transferId
    print("transfer started with id {0}".format(transfer_id))

    # monitor transfer status
    for transfer_info in client.MonitorTransfers(
            transfer_manager.RegistrationRequest(
                filters=[transfer_manager.RegistrationFilter(
                    transferId=[transfer_id]
                )])):
        print("transfer info {0}".format(transfer_info))

        # check transfer status in response, and exit if it's done
        status = transfer_info.status
        if status == transfer_manager.FAILED or status == transfer_manager.COMPLETED:
            print("finished {0}".format(status))
            break


def generate_source_file(name='file'):
    with open(name, 'w') as file:
        file.write('Hello World!')
    return os.path.abspath(name)


if __name__ == '__main__':
    run()
