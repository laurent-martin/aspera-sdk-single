import grpc
import json
import os.path

import transfer_pb2 as transfer_manager
import transfer_pb2_grpc as transfer_manager_grpc


def run():
    # create a connection to the transfer manager daemon
    client = transfer_manager_grpc.TransferServiceStub(grpc.insecure_channel('localhost:55002'))

    # create transfer spec
    transfer_spec = {
        "session_initiation": {
            "ssh": {
                "ssh_port": 33001,
                "remote_user": 'aspera',
                "remote_password": 'demoaspera'
            }
        },
        "direction": 'recv',
        "remote_host": 'demo.asperasoft.com',
        "assets": {
            "destination_root": os.path.abspath('.')
        }
    }
    transfer_spec = json.dumps(transfer_spec)

    # create a transfer request
    transfer_request = transfer_manager.TransferRequest(
        transferType=transfer_manager.FILE_PERSISTENT,
        config=transfer_manager.TransferConfig(),
        transferSpec=transfer_spec)

    # send start transfer request to transfer manager daemon
    transfer_response = client.StartTransfer(transfer_request)
    transfer_id = transfer_response.transferId
    print("transfer started with id {0}".format(transfer_id))

    # add file to persistent session
    client.AddTransferPaths(
        transfer_manager.TransferPathRequest(
            transferId=transfer_id,
            transferPath=[
                transfer_manager.TransferPath(
                    source='aspera-test-dir-small/10MB.1'
                )
            ]
        ))

    # monitor transfer status
    for transfer_info in client.MonitorTransfers(
            transfer_manager.RegistrationRequest(
                filters=[transfer_manager.RegistrationFilter(
                    transferId=[transfer_id]
                )])):
        print("transfer info {0}".format(transfer_info))

        # check transfer status in response, and exit if it's done
        event = transfer_info.transferEvent
        if event == transfer_manager.FILE_STOP or event == transfer_manager.FILE_ERROR:
            print("file finished {0}".format(event))
            break

    # lock the transfer
    client.LockPersistentTransfer(transfer_manager.LockPersistentTransferRequest(
        transferId=transfer_id
    ))
    print('lock persistent transfer')


if __name__ == '__main__':
    run()
