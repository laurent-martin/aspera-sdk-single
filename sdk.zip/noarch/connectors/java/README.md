# Aspera Transfer SDK - Java Examples

Aspera Transfer SDK Library Files

    src/main/protobuf/transfer.proto

### Requirements
- Java (tested with jdk 11)
- Gradle (installed automatically via gradle wrapper)

### Build
-     ./gradlew build

### Run
- In a separate window, start the transfer sdk daemon

      # from the aspera transfer sdk installation directory
      ./bin/asperatransferd

- Run the desired example

      java -cp build/libs/faspmanagerng-1.1-all.jar client.FileRegularUploadExample