﻿using System;
using System.IO;
using System.Text;
using Transfersdk;
using Grpc.Net.Client;
using Newtonsoft.Json.Linq;
using Path = System.IO.Path;

namespace TransferServiceExamples
{
    static class RegularFileExample
    {
        static void Main()
        {
            // create a connection to the transfer manager daemon
            AppContext.SetSwitch("System.Net.Http.SocketsHttpHandler.Http2UnencryptedSupport", true);

            var client = new TransferService.TransferServiceClient(GrpcChannel.ForAddress("http://localhost:55002"));

            // generate example file to transfer
            var filePath = GenerateSourceFile();

            // create a transfer spec string
            var transferSpec = JObject.Parse(@"
                {
                  'session_initiation': {
                            'ssh': {
                                'ssh_port': 33001,
                                'remote_user': 'aspera',
                                'remote_password': 'demoaspera'
                            }
                        },
                        'direction': 'send',
                        'remote_host': 'demo.asperasoft.com',
                        'title': 'strategic',
                        'assets': {
                            'destination_root': '/Upload',
                            'paths': [
                            {
                                'source': '" + filePath + @"'
                            }
                            ]
                        }
                    }
                ").ToString();

            // create a transfer request
            TransferRequest transferRequest = new TransferRequest
            {
                TransferType = TransferType.FileRegular,
                Config = new TransferConfig {LogLevel = 2},
                TransferSpec = transferSpec
            };

            // send start transfer request to the transfer manager daemon
            var startTransferResponse = client.StartTransfer(transferRequest);
            var transferId = startTransferResponse.TransferId;
            Console.Out.WriteLine("transfer started with id " + transferId);

            bool finished = false;
            while (!finished)
            {
                // check the current state of the transfer
                var queryTransferResponse = client.QueryTransfer(new TransferInfoRequest() {TransferId = transferId});
                Console.Out.WriteLine("transfer info " + queryTransferResponse);

                // check transfer status in response, and exit if it's done
                TransferStatus status = queryTransferResponse.Status;
                if (status == TransferStatus.Failed || status == TransferStatus.Completed)
                {
                    finished = true;
                    Console.Out.WriteLine("finished " + status);
                }

                // wait a second before checking again
                System.Threading.Thread.Sleep(1000);
            }
        }

        static string GenerateSourceFile(String name = "file")
        {
            using (var file = File.Open(name, FileMode.Create))
            {
                file.Write(Encoding.ASCII.GetBytes("Hello World!"));
            }

            return Path.GetFullPath(name).Replace('\\', '/');
        }
    }
}