package client;

import ibm.aspera.transferservice.Transfer;
import ibm.aspera.transferservice.TransferServiceGrpc;
import io.grpc.ManagedChannelBuilder;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Iterator;

public class FilePersistentExample {

    public static void main(String... args) throws IOException {
        // create a connection to the transfer sdk daemon
        TransferServiceGrpc.TransferServiceBlockingStub client =
                TransferServiceGrpc.newBlockingStub(
                        ManagedChannelBuilder.forAddress(
                                "localhost", 55002)
                                .usePlaintext()
                                .build());

        // create transfer spec string
        String transferSpec = "{\n" +
                "  \"session_initiation\": {\n" +
                "    \"ssh\": {\n" +
                "      \"ssh_port\": 33001,\n" +
                "      \"remote_user\": \"aspera\",\n" +
                "      \"remote_password\": \"demoaspera\"\n" +
                "    }\n" +
                "  },\n" +
                "  \"direction\": \"send\",\n" +
                "  \"remote_host\": \"demo.asperasoft.com\",\n" +
                "  \"assets\": {\n" +
                "    \"destination_root\": \"/Upload\"\n" +
                "  }\n" +
                "}";

        // send start transfer request to transfer sdk daemon
        Transfer.StartTransferResponse transferResponse =
                client.startTransfer(Transfer.TransferRequest.newBuilder()
                        .setTransferType(Transfer.TransferType.FILE_PERSISTENT)
                        .setConfig(Transfer.TransferConfig.newBuilder().build())
                        .setTransferSpec(transferSpec)
                        .build());
        String transferId = transferResponse.getTransferId();
        System.out.println("transfer started with id " + transferId);

        // generate example file to transfer
        String fileName = "file";
        String filePath = generateSourceFile(fileName);

        // add paths to persistent session
        Transfer.TransferPathRequest transferPathRequest =
                Transfer.TransferPathRequest.newBuilder()
                        .setTransferId(transferId)
                        .addTransferPath(Transfer.TransferPath.newBuilder()
                                .setSource(filePath)
                                .setDestination(fileName)
                                .build())
                        .build();
        client.addTransferPaths(transferPathRequest);
        System.out.println("add transfer path");

        // end the persistent session
        client.lockPersistentTransfer(Transfer.LockPersistentTransferRequest
                .newBuilder()
                .setTransferId(transferId)
                .build());
        System.out.println("lock persistent transfer");

        // monitor until persistent transfer has finished
        Iterator<Transfer.TransferResponse> monitorTransferResponse =
                client.monitorTransfers(
                        Transfer.RegistrationRequest.newBuilder()
                                .addFilters(Transfer.RegistrationFilter
                                        .newBuilder()
                                        .setOperator(Transfer.RegistrationFilterOperator.OR)
                                        .addTransferId(transferId)
                                        .build())
                                .build());

        while (monitorTransferResponse.hasNext()) {
            Transfer.TransferResponse info = monitorTransferResponse.next();
            System.out.println("info transferEvent " + info.getTransferEvent());

            if (info.getTransferEvent() == Transfer.TransferEvent.ARG_STOP) {
                System.out.println("file finished");
                break;
            }
        }
    }

    public static String generateSourceFile(String pFileName)
            throws IOException {
        File file = new File(pFileName);
        FileWriter writer = new FileWriter(file);
        writer.write("Hello World!");
        writer.close();
        return file.getAbsolutePath();
    }
}
