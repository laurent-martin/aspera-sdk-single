# Grpc generated classes are assumed to be in the load path
$LOAD_PATH << '.'

require 'transfer_services_pb'
require 'json'
require_relative 'utils'

include Transfersdk

def main
  # create a connection to the faspmanager daemon
  client = TransferService::Stub.new('localhost:55002',
                                     :this_channel_is_insecure)

  # generate example file to transfer
  file_path = Helper.generate_source_file

  # TODO: set your aws credentials and bucket here
  access_key_id = ''
  access_key_secret = '' # Note: key must be url-encoded
  s3_bucket = ''
  s3_destination_key = ''
  s3_endpoint = 's3.amazonaws.com'

  # create transfer spec string
  transfer_spec = {
    session_initiation: {
      ssh: {
        # TODO: Set the credentials of your remote machine with High Speed Transfer (with asperatrapd enabled)
        ssh_port: 22, # TODO: Set remote port (default is 33001)
        remote_user: '', # TODO: Set remote user
        remote_password: '' # TODO: Set remote password
      }
    },
    remote_host: '', # TODO: Set remote machine host address
    direction: 'send',
    title: 'regular_file_to_s3',
    assets: {
      destination_root: "s3://#{access_key_id}:#{access_key_secret}@#{s3_endpoint}/#{s3_bucket}/#{s3_destination_key}",
      paths: [
        {
          source: file_path
        }
      ]
    }
  }.to_json

  # create a transfer request
  transfer_request = TransferRequest.new(
    transferType: TransferType::FILE_REGULAR, # transfer type (file/stream)
    config: TransferConfig.new, # transfer configuration
    transferSpec: transfer_spec) # transfer definition

  # send start transfer request to the faspmanager daemon
  start_transfer_response = client.start_transfer(transfer_request)
  transfer_id = start_transfer_response.transferId
  puts "transfer started with id #{transfer_id}"

  status = nil
  loop do
    # check on the current state of the transfer
    transfer_info_request = TransferInfoRequest.new(transferId: transfer_id)
    transfer_info_response = client.query_transfer(transfer_info_request)
    puts "transfer info #{transfer_info_response}"

    # check transfer status in response, and exit if it's done
    status = transfer_info_response.status
    break if [:FAILED, :COMPLETED].include?(status)

    # wait a second before checking again
    sleep 1
  end

  puts "finished #{status}"
end

# program entry point
main if __FILE__ == $PROGRAM_NAME
