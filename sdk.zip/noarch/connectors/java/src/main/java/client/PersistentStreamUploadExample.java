package client;

import com.google.protobuf.ByteString;
import ibm.aspera.transferservice.Transfer;
import ibm.aspera.transferservice.TransferServiceGrpc;
import io.grpc.ManagedChannelBuilder;
import io.grpc.stub.StreamObserver;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

public class PersistentStreamUploadExample {

    public static void main(String... args) throws InterruptedException {

        // create a connection to the transfer sdk daemon
        final TransferServiceGrpc.TransferServiceStub client =
                TransferServiceGrpc.newStub(
                        ManagedChannelBuilder.forAddress(
                                "localhost", 55002)
                                .usePlaintext().build());

        // the exact size of the chunks we are streaming
        int chunkSize = 4096;

        // create transfer spec string
        String transferSpec = "{" +
                "  \"session_initiation\": {" +
                "    \"ssh\": {" +
                "      \"ssh_port\": 33001," +
                "      \"remote_user\": \"aspera\"," +
                "      \"remote_password\": \"demoaspera\"" +
                "    }" +
                "  }," +
                "  \"direction\": \"send\"," +
                "  \"remote_host\": \"demo.asperasoft.com\"," +
                "  \"assets\": {" +
                "    \"destination_root\": \"/Upload\"" +
                "  }," +
                "  \"transport\": {" +
                "    \"streaming\": {" +
                "      \"chunk_size\": " + chunkSize +
                "    }" +
                "  }" +
                "}";

        final CountDownLatch transferLatch = new CountDownLatch(1);
        // send asynchronous start transfer request
        client.startTransfer(Transfer.TransferRequest.newBuilder()
                .setTransferType(Transfer.TransferType.PERSISTENT_STREAM_UPLOAD)
                .setConfig(Transfer.TransferConfig.newBuilder().build())
                .setTransferSpec(transferSpec)
                .build(), new StreamObserver<>() {
            @Override
            public void onNext(Transfer.StartTransferResponse response) {
                System.out.println(String.format("transfer started with id %s",
                        response.getTransferId()));
                // once the transfer starts, write data
                try {
                    writeData(client, response.getTransferId(), chunkSize);
                } catch (InterruptedException e) {
                    System.out.println("failed to write data");
                }
                transferLatch.countDown();
            }

            @Override
            public void onError(Throwable t) {
                System.out.println("failed " + t.getMessage());
                transferLatch.countDown();
            }

            @Override
            public void onCompleted() {
                System.out.println("start transfer finished");
            }
        });
        // wait for our async transfer operation to finish
        transferLatch.await(10, TimeUnit.SECONDS);

        System.out.println("finished");
    }

    public static void writeData(
            TransferServiceGrpc.TransferServiceStub pClient,
            String pTransferId,
            int chunkSize) throws InterruptedException {

        // known size of data
        int size = chunkSize * 5;

        // your data
        ByteString chunk = ByteString.copyFrom(new byte[chunkSize]);

        // offset for write start (for specifying write chunk start, possible overwrite of previous chunks)
        long offset = 0;

        // get write stream observer
        CountDownLatch writeStreamLatch = new CountDownLatch(1);

        StreamObserver<Transfer.WriteStreamChunkRequest> writeStreamObserver =
                pClient.writeStreamChunk(new StreamObserver<>() {
                    @Override
                    public void onNext(Transfer.WriteStreamChunkResponse value) {
                        System.out.println(value);
                    }

                    @Override
                    public void onError(Throwable t) {
                        System.out.println("error while writing stream " +
                                t.getMessage());
                    }

                    @Override
                    public void onCompleted() {
                        System.out.println("write stream completed");
                        writeStreamLatch.countDown();
                    }
                });

        // write to the stream
        int bytesWritten = 0;
        while (bytesWritten < size) {
            int writeSize = Math.min(size - bytesWritten, chunk.size());

            // Write chunk to stream observer
            writeStreamObserver.onNext(
                    Transfer.WriteStreamChunkRequest.newBuilder()
                            .setTransferId(pTransferId)
                            .setPath("file")
                            .setRange(Transfer.TransferRange.newBuilder()
                                    .setOffset(offset)
                                    .setLength(chunk.size())
                                    .build())
                            .setChunk(Transfer.Chunk.newBuilder()
                                    .setContents(chunk)
                                    .build())
                            .build());

            offset += writeSize; // offset must be an integer multiple of chunk size
            bytesWritten += writeSize;
            System.out.println("bytes written " + bytesWritten);
        }

        // wait for the write stream to actually write
        writeStreamLatch.await(5, TimeUnit.SECONDS);
    }
}
