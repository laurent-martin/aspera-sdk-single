The src/main/protobuf should contain the *.proto files.

transfer.proto

