import grpc
import json
import os.path

import transfer_pb2 as transfer_manager
import transfer_pb2_grpc as transfer_manager_grpc


def run():
    # create a connection to the transfer manager daemon
    client = transfer_manager_grpc.TransferServiceStub(grpc.insecure_channel('localhost:55002'))

    # create transfer spec
    transfer_spec = {
        "session_initiation": {
            "ssh": {
                "ssh_port": 33001,
                "remote_user": "aspera",
                "remote_password": "demoaspera"
            }
        },
        "direction": "recv",
        "remote_host": "demo.asperasoft.com",
        "file_system": {
            # file to stream transfers must include the overwrite option
            "overwrite": "always"
        },
        "assets": {
            "paths": [
                {
                    "source": 'aspera-test-dir-small/10MB.1'
                },
                {
                    "source": 'aspera-test-dir-tiny/200KB.2'
                },
                {
                    "source": 'aspera-test-dir-tiny/200KB.3'
                }
            ]
        }
    }
    transfer_spec = json.dumps(transfer_spec)

    # create a transfer request
    transfer_request = transfer_manager.TransferRequest(
        transferType=transfer_manager.FILE_TO_STREAM_DOWNLOAD,
        config=transfer_manager.TransferConfig(),
        transferSpec=transfer_spec)

    # send start transfer request to transfer manager daemon
    transfer_response = client.StartTransfer(transfer_request)
    transfer_id = transfer_response.transferId
    print("transfer started with id {0}".format(transfer_id))

    # read data stream from from client
    read_stream_request = transfer_manager.ReadStreamRequest(transferId=transfer_id)

    # read data from stream
    for resp in client.ReadStream(read_stream_request):
        print(resp)

    print("finished")


if __name__ == '__main__':
    run()
