# Aspera Transfer SDK - Javascript Examples

Aspera Transfer SDK Library Files

        transfer.proto

### Requirements
- nodejs (tested with v14.4.0)
- protobuf
- grpc

### Setup
    npm install @grpc/grpc-js

### Run
- In a separate window, start the transfer sdk daemon

      # from the aspera transfer sdk installation directory
      ./bin/asperatransferd

- Run the desired example

      node regular_file_upload_example.js
