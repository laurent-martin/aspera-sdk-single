package main

import (
	"context"
	"fmt"
	"io"
	"log"
	"os"
	"path/filepath"
	"sync"

	"google.golang.org/grpc"
	"ibm.com/aspera/transfersdk/api/transfersdk"
)

func main() {

	// create a connection to the transfer manager daemon
	cc, err := grpc.Dial("127.0.0.1:55002", grpc.WithInsecure())
	if err != nil {
		log.Fatal(err)
	}
	defer cc.Close()
	client := transfersdk.NewTransferServiceClient(cc)

	// get sdk info
	request := &transfersdk.InstanceInfoRequest{}
	resp, err := client.GetInfo(context.Background(), request)
	if err != nil {
		fmt.Printf("Error %v\n", err.Error())
		return
	}
	fmt.Printf("Receive info response => [%v]\n", resp)

	// generate example file to transfer
	filePath, err := generateSourceFile()
	if err != nil {
		log.Fatal("Failed to create source file", err)
	}

	// create transfer spec
	transferSpec := `
{
  "session_initiation": {
    "ssh": {
      "ssh_port": 33001,
      "remote_user": "aspera",
      "remote_password": "demoaspera"
    }
  },
  "direction": "send",
  "remote_host": "demo.asperasoft.com",
  "title": "strategic",
  "assets": {
    "destination_root": "/Upload",
    "paths": [
      {
        "source": "` + filePath + `"
      }
    ]
  }
}`

	log.Printf("transfer spec %v", transferSpec)

	err = startTransferAndMonitor(transferSpec, client)
	if err != nil {
		log.Printf("Transfer failed %v", err)
	}
}

func generateSourceFile() (string, error) {
	name := "file"
	file, err := os.Create(name)
	if err != nil {
		return "", err
	}
	_, err = file.WriteString("Hello World!")
	if err != nil {
		return "", err
	}
	return filepath.Abs(name)
}

func getInfo(id string, client transfersdk.TransferServiceClient) {
	ctx := context.Background()
	req := transfersdk.TransferInfoRequest{
		TransferId: id,
	}
	info, err := client.QueryTransfer(ctx, &req)
	log.Printf("QueryTransferResponse: info: (%v) error:(%v)", info, err)
}

func startTransfer(transferSpec string, client transfersdk.TransferServiceClient) error {
	ctx := context.Background()
	transferrequest := &transfersdk.TransferRequest{
		TransferSpec: transferSpec,
	}
	startTransferResponse, err := client.StartTransfer(ctx, transferrequest)
	if err != nil {
		fmt.Printf("Error %v\n", err.Error())
		return err
	}

	log.Printf("TransferResponse: %v\n", startTransferResponse)
	return nil
}

func startTransferAndMonitor(transferSpec string, client transfersdk.TransferServiceClient) error {
	ctx := context.Background()

	// create transfer request
	transferrequest := &transfersdk.TransferRequest{
		TransferType: transfersdk.TransferType_FILE_REGULAR,
		Config: &transfersdk.TransferConfig{LogLevel: 2},
		TransferSpec: transferSpec,
	}

	// send start transfer request to the transfer manager daemon
	stream1, err1 := client.StartTransferWithMonitor(ctx, transferrequest)

	if err1 != nil {
		fmt.Printf("(Monitored)Error %v\n", err1.Error())
		return err1
	}

	for {
		transferresp, err := stream1.Recv()
		if err == io.EOF {
			log.Println("(Monitored) EOF")
			break
		}
		if err != nil {
			log.Fatalf("(Monitored)%v.TransferResponse(_) = _, %v", client, err)
		}
		log.Printf("(Monitored)TransferResponse: %v\n", transferresp)
	}

	return nil
}

func monitorTransfers(client transfersdk.TransferServiceClient) {
	request := &transfersdk.RegistrationRequest{}
	ctx := context.Background()
	stream, err := client.MonitorTransfers(ctx, request)
	if err != nil {
		log.Fatalf("(monitorTransfers)%v.TransferResponse(_) = _, %v", client, err)
		return
	}
	wg := sync.WaitGroup{}
	wg.Add(1)
	go func() {
		for {
			transferresp, err := stream.Recv()
			if err == io.EOF {
				break
			}
			if err != nil {
				log.Fatalf("(2)%v.TransferResponse(_) = _, %v", client, err)
			}
			log.Printf("(2)TransferResponse: %v", transferresp)
		}
		wg.Done()
	}()

	wg.Wait()

}
