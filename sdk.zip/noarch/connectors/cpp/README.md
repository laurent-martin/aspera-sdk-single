# Aspera Transfer SDK - C++ Examples

Aspera Transfer SDK Library Files

        transfer.pb.h
        transfer.pb.cc
        transfer.grpc.pb.h
        transfer.grpc.pb.cc

### Requirements
- CMake
- C++11 compatible compiler
- gRPC and Protobuf libraries

### Build
    mkdir build
    pushd build
    cmake ..
    make
    popd

If you have dependency problems, find tips in the `CMakeLists.txt` file.

### Run
- In a separate window, start the transfer sdk daemon

      # from the aspera transfer sdk installation directory
      ./bin/asperatransferd

- Run the desired example

      ./build/regular_file_example