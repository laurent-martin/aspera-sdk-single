# This examples shows the following data flow
# ((client app) -> localhost tcp -> (transfer manager ascp4)) -> FASP (public internet) -> ((server ascp4) -> localhost tcp -> (server app))
#
# To run this example
# - Start client tcp host as server for sending   (listening) (socket_tcp_send_data_as_server.rb)
# - Start server tcp host as server for receiving (listening) (socket_tcp_recv_data_as_server.rb) (on remote machine)
# - Set remote_host and ssh credentials (in transfer_spec below)
# - Run the example
#   - starts ascp4
#   - reads data from local tcp server
#   - sends data to remote ascp4, which writes to remote tcp server
#
# For example local and remote socket servers use the included ruby example servers.
#   - socket_tcp_send_data_as_server.rb (on client/source machine)
#   - socket_tcp_recv_data_as_server.rb (on remove/destination machine)
#
# Requires ascp4 streaming licenses

# Grpc generated classes are assumed to be in the load path
$LOAD_PATH << '.'

require 'json'
require 'transfer_services_pb'

include Transfersdk

def main
  # create a connection to the transfer sdk daemon
  client = TransferService::Stub.new('localhost:55002',
                                     :this_channel_is_insecure)

  # create transfer spec string
  transfer_spec =
    {
      session_initiation: {
        ssh: {
          ssh_port: 22,
          remote_user: 'root',
          remote_password: 'aspera'
        }
      },
      direction: 'send',
      remote_host: '172.0.0.2',
      assets: {
        paths: [
          {
            source: 'tcp://127.0.0.1:33333',
            destination: 'tcp://127.0.0.1:33333'
          }
        ]
      }
    }.to_json

  # create a transfer request
  transfer_request = TransferRequest.new(
    transferType: TransferType::URL_STREAM_TO_STREAM, # transfer type (file/stream)
    config: TransferConfig.new(
      localLog: "/tmp",
      remoteLog: "/tmp"), # transfer configuration
    transferSpec: transfer_spec
  ) # transfer definition

  # send start transfer request to the faspmanager daemon
  client.start_transfer_with_monitor(transfer_request) do |info|
    puts "transfer info #{info}"
  end

  puts 'finished'
end

# program entry point
main if __FILE__ == $PROGRAM_NAME
