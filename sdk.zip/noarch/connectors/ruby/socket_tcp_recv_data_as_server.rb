require 'socket'
require 'digest'

server = TCPServer.new('127.0.0.1', 33333)

digest = Digest::MD5.new

puts 'Listening...'
socket = server.accept
puts 'accepted'

while (data = socket.read(1024))
  digest << data
end

socket.close

puts digest
