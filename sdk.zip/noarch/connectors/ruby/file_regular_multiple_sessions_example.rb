# frozen_string_literal: true

# test many uploads
# Note: You may have to increase worker count
#   if you are running many concurrent transfers.
#   config/transfermanagerd.json
#   "workers": {
#     "max_concurrent": 10
#   }

# Grpc generated classes are assumed to be in the load path
$LOAD_PATH << '.'

require 'transfer_services_pb'

require_relative 'utils'

include Transfersdk

def main
  # create a connection to the transfer manager daemon
  client = TransferService::Stub.new('localhost:55002',
                                     :this_channel_is_insecure)

  transfer_ids = []

  FileUtils.mkdir_p('files')
  10.times do |i|
    # generate example file to transfer
    file_path = Helper.generate_source_file("files/file#{i}")

    # create transfer spec string
    transfer_spec = '
      {
        "session_initiation": {
          "ssh": {
            "ssh_port": 33001,
            "remote_user": "aspera",
            "remote_password": "demoaspera"
          }
        },
        "direction": "send",
        "remote_host": "demo.asperasoft.com",
        "title": "strategic",
        "assets": {
          "destination_root": "/Upload",
          "paths": [
            {
              "source": "' + file_path + '"
            }
          ]
        }
      }
      '

    # create a transfer request
    transfer_request = TransferRequest.new(
      transferType: TransferType::FILE_REGULAR, # transfer type (file/stream)
      config: TransferConfig.new(logLevel: 2), # transfer configuration
      transferSpec: transfer_spec
    ) # transfer definition

    # send start transfer request to the transfer manager daemon
    start_transfer_response = client.start_transfer(transfer_request)
    transfer_id = start_transfer_response.transferId
    puts "transfer started with id #{transfer_id}"

    # save id
    transfer_ids.push(transfer_id)
  end
  puts transfer_ids

  # monitor the transfers
  message_count = 0
  client.monitor_transfers(RegistrationRequest.new(
                             filters: [
                               RegistrationFilter.new(
                                 operator: RegistrationFilterOperator::OR,
                                 # transferId: transfer_ids,
                                 eventType: [
                                   TransferEvent::SESSION_STOP,
                                   TransferEvent::SESSION_ERROR
                                 ]
                               )
                             ]
                          )) do |result|
    puts "monitor transfers result #{result}"
    message_count += 1
    puts "message count #{message_count}"

    # remove from transfers if done
    id = result.transferId
    status = result.status
    if [:COMPLETED, :FAILED].include?(status)
      transfer_ids.delete(id)
      puts "remaining transfers #{transfer_ids.size} #{transfer_ids}"
    end

    # check for completion
    break if transfer_ids.empty?

    # sleep 1
  end

  puts 'finished'
end

# program entry point
main if __FILE__ == $PROGRAM_NAME
