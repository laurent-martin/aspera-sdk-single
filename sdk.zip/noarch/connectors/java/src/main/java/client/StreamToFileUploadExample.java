package client;

import com.google.protobuf.ByteString;
import ibm.aspera.transferservice.Transfer;
import ibm.aspera.transferservice.TransferServiceGrpc;
import io.grpc.ManagedChannelBuilder;
import io.grpc.stub.StreamObserver;

import java.nio.charset.StandardCharsets;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

public class StreamToFileUploadExample {

    public static void main(String... args) throws InterruptedException {

        // create a connection to the transfer sdk daemon
        final TransferServiceGrpc.TransferServiceStub client =
                TransferServiceGrpc.newStub(
                        ManagedChannelBuilder.forAddress(
                                "localhost", 55002)
                                .usePlaintext().build());

        // create transfer spec string
        String transferSpec = "{" +
                "  \"session_initiation\": {" +
                "    \"ssh\": {" +
                "      \"ssh_port\": 33001," +
                "      \"remote_user\": \"aspera\"," +
                "      \"remote_password\": \"demoaspera\"" +
                "    }" +
                "  }," +
                "  \"direction\": \"send\"," +
                "  \"remote_host\": \"demo.asperasoft.com\"," +
                "  \"assets\": {" +
                "    \"destination_root\": \"/Upload\"," +
                "    \"paths\": [" +
                "       {" +
                "         \"destination\": \"file\"" +
                "       }" +
                "     ]" +
                "  }" +
                "}";

        // send asynchronous start transfer request
        final CountDownLatch transferLatch = new CountDownLatch(1);
        client.startTransfer(Transfer.TransferRequest.newBuilder()
                .setTransferType(Transfer.TransferType.STREAM_TO_FILE_UPLOAD)
                .setConfig(Transfer.TransferConfig.newBuilder().build())
                .setTransferSpec(transferSpec)
                .build(), new StreamObserver<>() {
            @Override
            public void onNext(Transfer.StartTransferResponse response) {
                System.out.println(String.format("transfer started with id %s",
                        response.getTransferId()));
                // once the transfer starts, write data
                try {
                    writeData(client, response.getTransferId());
                } catch (InterruptedException e) {
                    System.out.println("failed to write data");
                }
                transferLatch.countDown();
            }

            @Override
            public void onError(Throwable t) {
                System.out.println("failed " + t.getMessage());
                transferLatch.countDown();
            }

            @Override
            public void onCompleted() {
                System.out.println("start transfer finished");
            }
        });
        // wait for our async transfer operation to finish
        transferLatch.await(10, TimeUnit.SECONDS);

        System.out.println("finished");
    }

    public static void writeData(
            TransferServiceGrpc.TransferServiceStub pClient,
            String pTransferId) throws InterruptedException {

        // known size of data
        int size = 42;
        String content = "Hello World!";

        // get write stream observer
        CountDownLatch writeStreamLatch = new CountDownLatch(1);
        StreamObserver<Transfer.WriteStreamRequest> writeStreamObserver =
                pClient.writeStream(new StreamObserver<>() {
                    @Override
                    public void onNext(Transfer.WriteStreamResponse value) {
                        System.out.println(value);
                    }

                    @Override
                    public void onError(Throwable t) {
                        System.out.println("error while writing stream " +
                                t.getMessage());
                    }

                    @Override
                    public void onCompleted() {
                        System.out.println("write stream completed");
                        writeStreamLatch.countDown();
                    }
                });

        // write to the stream
        int bytesWritten = 0;
        while (bytesWritten < size) {
            int writeSize = Math.min(size - bytesWritten, content.length());
            ByteString chunk = ByteString.copyFrom(
                    content.substring(0, writeSize),
                    StandardCharsets.UTF_8);

            // create write request
            Transfer.WriteStreamRequest writeStreamRequest =
                    Transfer.WriteStreamRequest.newBuilder()
                            .setTransferId(pTransferId)
                            .setPath("file")
                            .setSize(size)
                            .setChunk(Transfer.Chunk.newBuilder()
                                    .setContents(chunk).build())
                            .build();

            // send request via the observer
            writeStreamObserver.onNext(writeStreamRequest);

            bytesWritten += writeSize;
            System.out.println("bytes written " + bytesWritten);
        }

        // wait for the write stream to actually write
        writeStreamLatch.await(5, TimeUnit.SECONDS);
    }
}
