package client;

import ibm.aspera.transferservice.Transfer;
import ibm.aspera.transferservice.TransferServiceGrpc;
import io.grpc.ManagedChannelBuilder;
import io.grpc.stub.StreamObserver;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

public class FileToStreamDownloadExample {

    public static void main(String... args) throws InterruptedException {

        // create a connection to the transfer sdk daemon
        final TransferServiceGrpc.TransferServiceStub client = TransferServiceGrpc.newStub(
                ManagedChannelBuilder.forAddress("localhost", 55002).usePlaintext().build());

        // create transfer spec string
        String transferSpec = "{" +
                "  \"session_initiation\": {" +
                "    \"ssh\": {" +
                "      \"ssh_port\": 33001," +
                "      \"remote_user\": \"aspera\"," +
                "      \"remote_password\": \"demoaspera\"" +
                "    }" +
                "  }," +
                "  \"direction\": \"recv\"," +
                "  \"remote_host\": \"demo.asperasoft.com\"," +
                "  \"file_system\": {" +
                "    \"overwrite\": \"always\"" +
                "  }," +
                "  \"assets\": {" +
                "    \"paths\": [" +
                "       {" +
                "         \"source\": \"aspera-test-dir-small/10MB.1\"" +
                "       }," +
                "       {" +
                "         \"source\": \"aspera-test-dir-tiny/200KB.2\"" +
                "       }," +
                "       {" +
                "         \"source\": \"aspera-test-dir-tiny/200KB.3\"" +
                "       }" +
                "     ]" +
                "  }" +
                "}";

        final CountDownLatch transferLatch = new CountDownLatch(1);

        // send asynchronous start transfer request to transfer sdk daemon
        client.startTransfer(Transfer.TransferRequest.newBuilder()
                .setTransferType(Transfer.TransferType.FILE_TO_STREAM_DOWNLOAD)
                .setConfig(Transfer.TransferConfig.newBuilder().build())
                .setTransferSpec(transferSpec)
                .build(), new StreamObserver<>() {
            @Override
            public void onNext(Transfer.StartTransferResponse response) {
                System.out.println(String.format("transfer started with id %s", response.getTransferId()));
                // once the transfer starts, read data
                try {
                    readData(client, response.getTransferId());
                } catch (InterruptedException e) {
                    System.out.println("failed to write data");
                }
                transferLatch.countDown();
            }

            @Override
            public void onError(Throwable t) {
                System.out.println("failed " + t.getMessage());
                transferLatch.countDown();
            }

            @Override
            public void onCompleted() {
                System.out.println("transfer finished");
            }
        });
        // wait for our async transfer operation to finish
        transferLatch.await(10, TimeUnit.SECONDS);
    }


    public static void readData(TransferServiceGrpc.TransferServiceStub pClient, String pTransferId) throws InterruptedException {

        CountDownLatch streamLatch = new CountDownLatch(1);

        pClient.readStream(Transfer.ReadStreamRequest.newBuilder()
                        .setTransferId(pTransferId)
                        .build(),
                new StreamObserver<Transfer.ReadStreamResponse>() {
                    @Override
                    public void onNext(Transfer.ReadStreamResponse value) {
                        System.out.println("path " + value.getPath() + ", path size " +  value.getPathSize());
                    }

                    @Override
                    public void onError(Throwable t) {
                        System.out.println("error while reading stream " + t.getMessage());
                    }

                    @Override
                    public void onCompleted() {
                        System.out.println("finished reading stream");
                        streamLatch.countDown();
                    }
                });

        // wait for the write stream to actually write
        streamLatch.await(5, TimeUnit.SECONDS);
    }
}
