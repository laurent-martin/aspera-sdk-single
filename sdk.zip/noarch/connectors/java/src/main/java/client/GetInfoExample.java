package client;

import ibm.aspera.transferservice.Transfer;
import ibm.aspera.transferservice.TransferServiceGrpc;
import io.grpc.ManagedChannelBuilder;

public class GetInfoExample {

    public static void main(String... args) {
        // create a connection to the transfer sdk daemon
        TransferServiceGrpc.TransferServiceBlockingStub client = TransferServiceGrpc.newBlockingStub(
                ManagedChannelBuilder.forAddress("localhost", 55002).usePlaintext().build());

        // create a get transfer sdk instance info request
        Transfer.InstanceInfoResponse infoResponse = client.getInfo(Transfer.InstanceInfoRequest.newBuilder().build());
        System.out.println(String.format("instance info %s", infoResponse));
    }
}
