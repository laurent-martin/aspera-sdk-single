require 'fileutils'

module Helper
  def self.generate_source_file(path = 'file')
    open(path, 'w') do |f|
      f.write('Hello World!')
    end
    File.absolute_path(path)
  end

  def self.working_dir
    FileUtils.pwd
  end
end
