# Aspera Transfer SDK - Go Examples

Aspera Transfer SDK Library Files

        transfer.pb.go

### Requirements
- Go (tested with go1.14.4)

### Build
- Build the example you want to run

      go build regular_file_example.go

### Run
- In a separate window, start the transfer sdk daemon

      # from the aspera transfer sdk installation directory
      ./bin/asperatransferd

- Run the desired example

      ./regular_file_example

### To build your own stub

- In the working directory, create a directory to hold the API

```sh   
 mkdir api/transfersdk
```
- From the archive shipped by IBM, get a copy of the proto file (`transfer.proto`) into the created folder  

```sh   
cp ../transfer.proto api/transfersdk/
```

- Now generate the stub into teh directory that you created earlier   

```sh   
protoc --go_out=plugins=grpc:api/transfersdk --proto_path api/transfersdk/ api/transfersdk/transfer.proto
```

(visit https://grpc.io/docs/protoc-installation/ to install protoc if needed)

- Add a go.mod file in the new generated path api/transfersdk/ibm.com/aspera/transfersdk/


```sh   
echo "module transfersdk" > api/transfersdk/ibm.com/aspera/transfersdk/go.mod
```
You actually just need api/transfersdk/ibm.com/aspera/transfersdk/transfer.pb.go and api/transfersdk/ibm.com/aspera/transfersdk/go.mod onwards.


- Edit the go.mod file in your working directory to have  
` replace ibm.com/aspera/transfersdk/api/transfersdk => ./api/transfersdk/ibm.com/aspera/transfersdk`   
instead (to point to the location of api/transfersdk/ibm.com/aspera/transfersdk/transfer.pb.go and api/transfersdk/ibm.com/aspera/transfersdk/go.mod)

Eg   
```
module client

go 1.16

replace ibm.com/aspera/transfersdk/api/transfersdk => ./api/transfersdk/ibm.com/aspera/transfersdk
```

- Now download the dependencies by running


```sh  
go get google.golang.org/grpc
go get ibm.com/aspera/transfersdk/api/transfersdk
```   

- You are ready to build the sample go build regular_file_example.go
