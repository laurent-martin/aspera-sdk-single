
#include <iostream>
#include <fstream>
#include <filesystem>
#include <thread>

#include <grpcpp/create_channel.h>

#include "transfer.grpc.pb.h"

namespace filesystem = std::__fs::filesystem;

using grpc::Channel;
using grpc::ClientContext;
using grpc::Status;

std::string statusToString(int status) {
    switch (status) {
        default:
        case 0:
            return "UNKNOWN_TRANSFER_STATUS";
        case 1:
            return "QUEUED";
        case 2:
            return "RUNNING";
        case 3:
            return "COMPLETED";
        case 4:
            return "FAILED";
        case 5:
            return "CANCELED";
        case 6:
            return "PAUSED";
        case 7:
            return "ORPHANED";
    }
}

int main() {

    // create a connection to the transfer sdk daemon
    std::unique_ptr<transfersdk::TransferService::Stub> client = transfersdk::TransferService::NewStub(
            grpc::CreateChannel("localhost:55002", grpc::InsecureChannelCredentials()));

    // create transfer spec string
    std::string transferSpec = "{"
                               "  \"session_initiation\": {"
                               "    \"ssh\": {"
                               "      \"ssh_port\": 33001,"
                               "      \"remote_user\": \"aspera\","
                               "      \"remote_password\": \"demoaspera\""
                               "    }"
                               "  },"
                               "  \"direction\": \"recv\","
                               "  \"remote_host\": \"demo.asperasoft.com\","
                               "  \"file_system\": {"
                               "    \"overwrite\": \"always\""
                               "  },"
                               "  \"assets\": {"
                               "    \"paths\": ["
                               "      {"
                               "        \"source\": \"aspera-test-dir-small/10MB.1\""
                               "      },"
                               "      {"
                               "        \"source\": \"aspera-test-dir-tiny/200KB.2\""
                               "      },"
                               "      {"
                               "        \"source\": \"aspera-test-dir-tiny/200KB.3\""
                               "      }"
                               "    ]"
                               "  }"
                               "}";

    // create a transfer request
    transfersdk::TransferRequest transferRequest;
    transferRequest.set_transfertype(transfersdk::TransferType::FILE_TO_STREAM_DOWNLOAD);
    auto *transferConfig = new transfersdk::TransferConfig;
    transferConfig->set_loglevel(2);
    transferRequest.set_allocated_config(transferConfig);
    transferRequest.set_transferspec(transferSpec);

    // send start transfer request to the transfer sdk daemon
    ClientContext startTransferContext;
    transfersdk::StartTransferResponse startTransferResponse;
    client->StartTransfer(&startTransferContext, transferRequest, &startTransferResponse);
    std::string transferId = startTransferResponse.transferid();
    if (startTransferResponse.error().code()) {
        std::cout << "start transfer error "
                  << startTransferResponse.error().code() << " "
                  << startTransferResponse.error().description()
                  << std::endl;
    }
    std::cout << "transfer started with id " << transferId << std::endl;

    // read data stream from transfer
    transfersdk::ReadStreamRequest readStreamRequest;
    readStreamRequest.set_transferid(transferId);
    ClientContext readStreamContext;
    transfersdk::ReadStreamResponse readStreamResponse;
    std::unique_ptr<::grpc::ClientReader<::transfersdk::ReadStreamResponse>> readStream =
            client->ReadStream(&readStreamContext, readStreamRequest);

    transfersdk::ReadStreamResponse response;
    while (readStream->Read(&response)) {
        std::cout << "response "
                  << " path: " << response.path()
                  << " pathSize: " << response.pathsize()
                  << " chunk: " << "<size: " << response.chunk().ByteSizeLong() << "> " // response.chunk().contents()
                  << " error: " << response.error().code() << " " << response.error().description()
                  << std::endl;
    }
    grpc::Status status = readStream->Finish();
    std::cout << "finished " << status.error_code() << std::endl;

    return 0;
}
