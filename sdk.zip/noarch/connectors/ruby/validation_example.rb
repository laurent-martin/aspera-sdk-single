# Grpc generated classes are assumed to be in the load path
$LOAD_PATH << '.'

require 'transfer_services_pb'

require_relative 'utils'

include Transfersdk

def main

  # create a connection to the faspmanager daemon
  client = TransferService::Stub.new('localhost:55002',
                                     :this_channel_is_insecure)

  # generate example file to transfer
  file_path = Helper.generate_source_file

  # create transfer spec string
  transfer_spec = '
{
  "session_initiation": {
    "ssh": {
      "ssh_port": 33001,
      "remote_user": "aspera",
      "remote_password": "demoaspera"
    }
  },
  "direction": "send",
  "remote_host": "demo.asperasoft.com",
  "assets": {
    "destination_root": "/Upload",
    "paths": [
      {
        "source": "' + file_path + '"
      }
    ]
  }
}
'

  validation_request = ValidationRequest.new(
    transferType: TransferType::FILE_REGULAR,
    transferSpec: transfer_spec)
  validation_response = client.validate(validation_request)
  puts "validation response #{validation_response}"

end

# program entry point
main if __FILE__ == $PROGRAM_NAME
