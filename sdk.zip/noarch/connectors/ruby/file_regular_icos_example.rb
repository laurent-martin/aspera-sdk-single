# Grpc generated classes are assumed to be in the load path
$LOAD_PATH << '.'
require 'transfer_services_pb'

require 'json'
require_relative 'utils'

include Transfersdk

def main
  # create a connection to the transfer manager daemon
  client = TransferService::Stub.new('localhost:55002',
                                     :this_channel_is_insecure)

  # generate example file to transfer
  file_path = Helper.generate_source_file('file')

  # create transfer spec string

  transfer_spec =
    {
      paths: [
        {
          source: file_path
        }
      ],
      title: 'ICOS file upload',
      cipher: 'aes-128',
      direction: 'send',
      overwrite: 'always',
      create_dir: true,
      target_rate_kbps: 150000,
      remote_host: 'demo.asperasoft.com',
      destination_root: '/',
      remote_user: 'asperaweb',
      remote_password: 'demoaspera',
      ssh_port: 33001,
      # TODO: Add storage information
      icos: {
        api_key: '',
        bucket: '',
        ibm_service_instance_id: '',
        ibm_service_endpoint: ''
      },
    }.to_json

  puts "transfer spec #{transfer_spec}"

  # create a transfer request
  transfer_request = TransferRequest.new(
    transferType: TransferType::FILE_REGULAR, # transfer type (file/stream)
    config: TransferConfig.new, # transfer configuration
    transferSpec: transfer_spec
  ) # transfer definition

  # send start transfer request to the transfer manager daemon
  start_transfer_response = client.start_transfer(transfer_request)
  transfer_id = start_transfer_response.transferId
  puts "transfer started with id #{transfer_id}"

  # monitor transfer status
  client.monitor_transfers(
    RegistrationRequest.new(
      filters: [
        RegistrationFilter.new(
          operator: RegistrationFilterOperator::OR,
          transferId: [transfer_id]
        )
      ]
    )
  ) do |response|
    puts "transfer info #{response}"

    # check transfer status in response, and exit if it's done
    status = response.status
    if [:FAILED, :COMPLETED].include?(status)
      puts "finished #{status}"
      break
    end
  end
end

main if __FILE__ == $PROGRAM_NAME
