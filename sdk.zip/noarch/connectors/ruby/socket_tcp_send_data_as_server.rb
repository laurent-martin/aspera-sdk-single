require 'socket'
require 'digest'

server = TCPServer.new('127.0.0.1', 33333)

puts 'Listening...'
socket = server.accept
puts 'accepted'

digest = Digest::MD5.new

10.times do |i|
  puts "sending #{i}"
  data = i.to_s
  socket.send(data, 0)
  digest << data
end

socket.flush
socket.close

puts digest
