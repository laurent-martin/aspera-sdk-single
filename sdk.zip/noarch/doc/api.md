# Protocol Documentation
<a name="top"></a>

## Table of Contents

- [api/transfersdk/transfer.proto](#api_transfersdk_transfer-proto)
    - [APIVersionRequest](#transfersdk-APIVersionRequest)
    - [APIVersionResponse](#transfersdk-APIVersionResponse)
    - [AsperaInfo](#transfersdk-AsperaInfo)
    - [Assets](#transfersdk-Assets)
    - [BasicRetryStrategy](#transfersdk-BasicRetryStrategy)
    - [Chunk](#transfersdk-Chunk)
    - [Compression](#transfersdk-Compression)
    - [Error](#transfersdk-Error)
    - [ExponentialBackoffRetryStrategy](#transfersdk-ExponentialBackoffRetryStrategy)
    - [FASPProxy](#transfersdk-FASPProxy)
    - [FileTransferInformation](#transfersdk-FileTransferInformation)
    - [Filesystem](#transfersdk-Filesystem)
    - [HTTPFallback](#transfersdk-HTTPFallback)
    - [ICOSSpec](#transfersdk-ICOSSpec)
    - [Initiation](#transfersdk-Initiation)
    - [InstanceInfo](#transfersdk-InstanceInfo)
    - [InstanceInfoRequest](#transfersdk-InstanceInfoRequest)
    - [InstanceInfoResponse](#transfersdk-InstanceInfoResponse)
    - [LicenseInfo](#transfersdk-LicenseInfo)
    - [LockPersistentTransferRequest](#transfersdk-LockPersistentTransferRequest)
    - [LockPersistentTransferResponse](#transfersdk-LockPersistentTransferResponse)
    - [MultiSession](#transfersdk-MultiSession)
    - [MultiSessionBandwidth](#transfersdk-MultiSessionBandwidth)
    - [MultiSessionFileSplitting](#transfersdk-MultiSessionFileSplitting)
    - [MultiSessionHosts](#transfersdk-MultiSessionHosts)
    - [NodeAPIHeaderSpec](#transfersdk-NodeAPIHeaderSpec)
    - [NodeAPISpec](#transfersdk-NodeAPISpec)
    - [Path](#transfersdk-Path)
    - [PathPattern](#transfersdk-PathPattern)
    - [PeerCheckRequest](#transfersdk-PeerCheckRequest)
    - [PeerCheckResponse](#transfersdk-PeerCheckResponse)
    - [QueryTransferResponse](#transfersdk-QueryTransferResponse)
    - [ReadStreamRequest](#transfersdk-ReadStreamRequest)
    - [ReadStreamResponse](#transfersdk-ReadStreamResponse)
    - [RegistrationFilter](#transfersdk-RegistrationFilter)
    - [RegistrationRequest](#transfersdk-RegistrationRequest)
    - [RetryStrategy](#transfersdk-RetryStrategy)
    - [SSHSpec](#transfersdk-SSHSpec)
    - [Security](#transfersdk-Security)
    - [SessionTransferInformation](#transfersdk-SessionTransferInformation)
    - [StartTransferResponse](#transfersdk-StartTransferResponse)
    - [StopInfo](#transfersdk-StopInfo)
    - [StopTransferRequest](#transfersdk-StopTransferRequest)
    - [StopTransferResponse](#transfersdk-StopTransferResponse)
    - [Streaming](#transfersdk-Streaming)
    - [Tracking](#transfersdk-Tracking)
    - [TransferConfig](#transfersdk-TransferConfig)
    - [TransferInfo](#transfersdk-TransferInfo)
    - [TransferInfoRequest](#transfersdk-TransferInfoRequest)
    - [TransferModificationRequest](#transfersdk-TransferModificationRequest)
    - [TransferModificationResponse](#transfersdk-TransferModificationResponse)
    - [TransferPath](#transfersdk-TransferPath)
    - [TransferPathRequest](#transfersdk-TransferPathRequest)
    - [TransferPathResponse](#transfersdk-TransferPathResponse)
    - [TransferRange](#transfersdk-TransferRange)
    - [TransferRequest](#transfersdk-TransferRequest)
    - [TransferResponse](#transfersdk-TransferResponse)
    - [TransferSpecV1](#transfersdk-TransferSpecV1)
    - [TransferSpecV2](#transfersdk-TransferSpecV2)
    - [Transport](#transfersdk-Transport)
    - [ValidationRequest](#transfersdk-ValidationRequest)
    - [ValidationResponse](#transfersdk-ValidationResponse)
    - [WriteStreamChunkRequest](#transfersdk-WriteStreamChunkRequest)
    - [WriteStreamChunkResponse](#transfersdk-WriteStreamChunkResponse)
    - [WriteStreamRequest](#transfersdk-WriteStreamRequest)
    - [WriteStreamResponse](#transfersdk-WriteStreamResponse)
  
    - [RegistrationFilterOperator](#transfersdk-RegistrationFilterOperator)
    - [TransferEvent](#transfersdk-TransferEvent)
    - [TransferStatus](#transfersdk-TransferStatus)
    - [TransferType](#transfersdk-TransferType)
  
    - [TransferService](#transfersdk-TransferService)
  
- [Scalar Value Types](#scalar-value-types)



<a name="api_transfersdk_transfer-proto"></a>
<p align="right"><a href="#top">Top</a></p>

## api/transfersdk/transfer.proto



<a name="transfersdk-APIVersionRequest"></a>

### APIVersionRequest
An empty request that gets the API version






<a name="transfersdk-APIVersionResponse"></a>

### APIVersionResponse
Returns a list of all versions of the API that the transfer binary supports.


| Field | Type | Label | Description |
| ----- | ---- | ----- | ----------- |
| supportedVersions | [string](#string) | repeated | Supported versions of the API |






<a name="transfersdk-AsperaInfo"></a>

### AsperaInfo
Information about the Aspera transfer binary


| Field | Type | Label | Description |
| ----- | ---- | ----- | ----------- |
| asperaBinary | [string](#string) |  | Name of IBM Aspera binary (ascp or ascp4) |
| asperaVersion | [string](#string) |  | Version number of the IBM Aspera binary |
| operatingSystem | [string](#string) |  | User&#39;s operating system |
| error | [Error](#transfersdk-Error) |  | Error that is returned |






<a name="transfersdk-Assets"></a>

### Assets
Assets for the transfer


| Field | Type | Label | Description |
| ----- | ---- | ----- | ----------- |
| destination_root_id | [string](#string) |  | File ID of the destination root directory. Required if using bearer token authorization for the destination node. |
| source_root_id | [string](#string) |  | File ID of the source root directory |
| destination_root | [string](#string) |  | Destination root directory |
| source_root | [string](#string) |  | Source root directory |
| paths | [Path](#transfersdk-Path) | repeated | Array of paths |






<a name="transfersdk-BasicRetryStrategy"></a>

### BasicRetryStrategy
When a transfer fails, a simple strategy to retry the transfer until it completes


| Field | Type | Label | Description |
| ----- | ---- | ----- | ----------- |
| maxCount | [int64](#int64) |  | Maximum number of times to retry the transfer |
| retryInterval | [int64](#int64) |  | Interval to wait before retrying the transfer |






<a name="transfersdk-Chunk"></a>

### Chunk
Information about data packets


| Field | Type | Label | Description |
| ----- | ---- | ----- | ----------- |
| contents | [bytes](#bytes) |  | Byte array sent in streaming request and returned in response (both send and receive) |






<a name="transfersdk-Compression"></a>

### Compression
Compression object containing a string. Compresses file data inline.
Allowable values: none, zlib, lz4. (Default: lz4). If set to zlib, the compression hint can be used to set the compression level.


| Field | Type | Label | Description |
| ----- | ---- | ----- | ----------- |
| method | [string](#string) |  | The method for compressing file data. Allowable values: none, zlib, lz4. (Default: lz4). If set to zlib, the compression hint can be used to set the compression level. |
| hint | [int32](#int32) |  | Compress file data to the specified level when the compression method is set to an option that accepts compression level settings (currently only zlib). A lower value results in less, but faster, data compression (0 = no compression). A higher value results in greater, slower compression. Valid values are &#34;-1&#34; to &#34;9&#34;, where &#34;-1&#34; is &#34;balanced&#34;. (Default: &#34;-1&#34;) |






<a name="transfersdk-Error"></a>

### Error
Error message in response


| Field | Type | Label | Description |
| ----- | ---- | ----- | ----------- |
| code | [int32](#int32) |  | Error code |
| description | [string](#string) |  | Description of error |






<a name="transfersdk-ExponentialBackoffRetryStrategy"></a>

### ExponentialBackoffRetryStrategy
When a transfer fails, the exponential strategy for waiting and retrying. The wait time grows exponentially with each retry attempt.


| Field | Type | Label | Description |
| ----- | ---- | ----- | ----------- |
| maxAttempts | [int64](#int64) |  | Maximum number of times to wait and retry before failing the transfer |
| multiplier | [int64](#int64) |  | The exponential multiplier for the wait time. If &lt; 1, default is 2. |
| initialDelay | [int64](#int64) |  | Length of the initial wait time before retrying the transfer. |
| maxDelay | [int64](#int64) |  | Maximum duration of wait time before retrying the transfer. If &lt;= zero, no maximum is enforced. |






<a name="transfersdk-FASPProxy"></a>

### FASPProxy
Access parameters for the Proxy that coordinates communications between the remote server and the (local) client.


| Field | Type | Label | Description |
| ----- | ---- | ----- | ----------- |
| url | [string](#string) |  | URL of proxy server |
| username | [string](#string) |  | Username for the proxy user |
| password | [string](#string) |  | Password for the proxy user |






<a name="transfersdk-FileTransferInformation"></a>

### FileTransferInformation
Returned information about the transfer


| Field | Type | Label | Description |
| ----- | ---- | ----- | ----------- |
| fileId | [string](#string) |  | File ID |
| path | [string](#string) |  | Path for the file transfer |
| startTimeUsec | [int64](#int64) |  | Transfer start time, in microseconds |
| elapsedUsec | [int64](#int64) |  | Total time elapsed during the transfer, in microseconds |
| status | [string](#string) |  | Status of the transfer |
| errorCode | [int64](#int64) |  | Error code |
| errorDescription | [string](#string) |  | Description of the error |
| size | [int64](#int64) |  | Transfer size (MB) |
| fileType | [string](#string) |  | Type of file that was transferred |
| fileChecksumType | [string](#string) |  | Hash of the file checksum. Allowable values: sha-512,sha-384,sha-256,sha1,md5. (Default: none) |
| checksum | [string](#string) |  | Hash from fileChecksumType |
| startByte | [int64](#int64) |  | Offset where file is written |
| bytesWritten | [int64](#int64) |  | Total bytes written at the destination |
| bytesContiguous | [int64](#int64) |  | From startByte, how many contiguous bytes have been written |
| sessionId | [string](#string) |  | Unique ID that FASP assigns to a transfer session |
| faspFileArgIndex | [int64](#int64) |  | Command line argument index that specified this file (if argument was a directory, many files can have the same FaspFileArgIndex). In persistent mode, the argument is constantly increasing. |






<a name="transfersdk-Filesystem"></a>

### Filesystem
Policies related to transfer assets


| Field | Type | Label | Description |
| ----- | ---- | ----- | ----------- |
| create_dir | [bool](#bool) |  | Create a directory at the transfer destination |
| delete_before_transfer | [bool](#bool) |  | Before transfer, delete files that exist at the destination but not at the source. The source and destination arguments must be directories that have matching names. Objects on the destination that have the same name but different type or size as objects on the source are not deleted. |
| exclude_newer_than | [string](#string) |  | Exclude files (but not directories) that are newer than a specific time from the transfer, based on when the file was last modified. Express in ISO 8601 format (for example, 2006-01-02T15:04:05Z) or as number of seconds elapsed since 00:00:00 UTC on 1 January 1970. |
| exclude_older_than | [string](#string) |  | Exclude files (but not directories) that are older than a specific time from the transfer, based on when the file was last modified. Express in ISO 8601 format (for example, 2006-01-02T15:04:05Z) or as number of seconds elapsed since 00:00:00 UTC on 1 January 1970. |
| move_after_transfer | [string](#string) |  | Move source files under path the path after transfer success. |
| overwrite | [string](#string) |  | Overwrite files at the destination with source files of the same name based on the policy: - always – Always overwrite the file. - never – Never overwrite the file. If the destination contains partial files that are older or the same as the source files and resume is enabled, the partial files resume transfer. Partial files with checksums or sizes that differ from the source files are not overwritten. - diff – Overwrite the file if it is different from the source, depending on the compare method (default is size). If the destination is object storage, diff has the same effect as always. If resume is not enabled, partial files are overwritten if they are different from the source, otherwise they are skipped. If resume is enabled, only partial files with different sizes or checksums from the source are overwritten; otherwise, files resume. - diff&#43;older – Overwrite the file if it is older and different from the source, depending on the compare method (default is size). If resume is not enabled, partial files are overwritten if they are older and different from the source, otherwise they are skipped. If resume is enabled, only partial files that are different and older than the source are overwritten, otherwise they are resumed. - older – Overwrite the file if its timestamp is older than the source timestamp.

If you set an overwrite policy of diff or diff&#43;older, difference is determined by the value set for resume_policy: &#34;none&#34; - the source and destination files are always considered different and the destination file is always overwritten &#34;attributes&#34; - the source and destination files are compared based on file attributes &#34;sparse_checksum&#34; - the source and destination files are compared based on sparse checksums, (currently file size) &#34;full_checksum&#34; - the source and destination files are compared based on full checksums |
| precalculate_job_size | [bool](#bool) |  | Restore the access time of the source file to the last access prior to transfer, which the source considers an access. |
| preserve_access_time | [bool](#bool) |  | Preserve the time the file was last accessed (read or write access) on the source. |
| preserve_creation_time | [bool](#bool) |  | Preserve timestamp for when a file was created |
| preserve_modification_time | [bool](#bool) |  | Preserve the time the object was last modified (write access) on the source. |
| preserve_times | [bool](#bool) |  |  |
| remove_after_transfer | [bool](#bool) |  | Remove files at the source of the transfer after the transfer completes successfully |
| remove_empty_directories | [bool](#bool) |  | Remove empty subdirectories at the source of the transfer |
| resume_policy | [string](#string) |  | If a transfer is interrupted or fails to finish, this policy directs the transfer to resume without retransferring the files. Allowable values: &#34;none&#34; – always re-transfer the entire file &#34;attributes&#34; – compare file attributes and resume if they match, and re-transfer if they do not &#34;sparse_checksum&#34; – compare file attributes and the sparse file checksums; resume if they match, and re-transfer if they do not &#34;full_checksum&#34; – compare file attributes and the full file checksums; resume if they match, and re-transfer if they do not. |
| symlink_policy | [string](#string) |  | The method for processing symbolic links. Allowable values: follow, copy, copy&#43;force, skip |
| checksum_type | [string](#string) |  | Enable checksum reporting for transferred files by specifying the hash to use. Allowable values: sha-512, sha-384, sha-256, sha1, md5. (Default: none) |
| src_base64 | [string](#string) |  | The folder name below which the directory structure is preserved (base64 encoded) |
| inclusion_patterns | [PathPattern](#transfersdk-PathPattern) | repeated | Include files or directories from the transfer based on the specified pattern. Rules are applied in the order in which they are encountered, from left to right. The following symbols can be used in the pattern: - * (asterisk) represents zero or more characters in a string, for example *.tmp matches .tmp and abcde.tmp. - ? (question mark) represents a single character, for example t?p matches tmp but not temp. |
| exclusion_patterns | [PathPattern](#transfersdk-PathPattern) | repeated | Exclude files or directories from the transfer based on the specified pattern. Rules are applied in the order in which they are encountered, from left to right. The following symbols can be used in the pattern: - * (asterisk) represents zero or more characters in a string, for example *.tmp matches .tmp and abcde.tmp. - ? (question mark) represents a single character, for example t?p matches tmp but not temp. |
| apply_local_docroot | [bool](#bool) |  | Apply the local docroot. This option is used to avoid entering object storage access credentials in the command line. Allowable values: true, false. |
| preserve_acls | [string](#string) |  | Preserve access control lists. Allowable values: none, native, metafile. |
| preserve_remote_acls | [string](#string) |  | Preserve remote access control lists. Allowable values: none, native, metafile |
| preserve_file_owner_uid | [bool](#bool) |  | Preserve the user ID for a file owner |
| preserve_file_owner_gid | [bool](#bool) |  | Preserve the group ID for a file owner |
| preserve_extended_attrs | [string](#string) |  | Preserve the extended attributes. Allowable values: none, native, metafile |
| preserve_remote_extended_attrs | [string](#string) |  | Preserve the extended attributes for a remote server. Allowable values: none, native, metafile |
| preserve_source_access_time | [bool](#bool) |  | Preserve the time logged for when the source file was accessed |
| remove_empty_source_dir | [bool](#bool) |  | Remove empty source subdirectories and remove the source directory itself, if empty |
| save_before_overwrite | [bool](#bool) |  | Rename the file instead of overwriting it. Allowable values: true, false. |
| skip_duplicate_check | [bool](#bool) |  | Don&#39;t check for duplicate files at the destination. Allowable values: true, false. |
| skip_special_files | [bool](#bool) |  | All assets other than files, directories and symbolic links are considered special. A transfer will fail if the user attempts to transfer special assets. If true, ascp skips special assets and proceeds with the transfer of all other assets. |






<a name="transfersdk-HTTPFallback"></a>

### HTTPFallback
Configuration for HTTP fallback


| Field | Type | Label | Description |
| ----- | ---- | ----- | ----------- |
| port | [int64](#int64) |  | Port used for HTTP fallback server |
| proxy | [string](#string) |  | Proxy address and port. (Default: 80) |






<a name="transfersdk-ICOSSpec"></a>

### ICOSSpec
Configuration for IBM Cloud Object Storage


| Field | Type | Label | Description |
| ----- | ---- | ----- | ----------- |
| api_key | [string](#string) |  | API key for IBM Cloud Object Storage |
| bucket | [string](#string) |  | CRN (cloud resource name) for the bucket |
| ibm_service_instance_id | [string](#string) |  | Instance ID for the IBM service |
| ibm_service_endpoint | [string](#string) |  | Endpoint for the IBM service |






<a name="transfersdk-Initiation"></a>

### Initiation
Elements of transfer initiation


| Field | Type | Label | Description |
| ----- | ---- | ----- | ----------- |
| ssh | [SSHSpec](#transfersdk-SSHSpec) |  | Parameters relating to SSH |
| icos | [ICOSSpec](#transfersdk-ICOSSpec) |  | Parameters relating to IBM Cloud Object Storage |
| node_api | [NodeAPISpec](#transfersdk-NodeAPISpec) |  | Configuration parameters for a call to the Node API |






<a name="transfersdk-InstanceInfo"></a>

### InstanceInfo
Data about the Transfer SDK service instance


| Field | Type | Label | Description |
| ----- | ---- | ----- | ----------- |
| managementPort | [int64](#int64) |  | Port the Transfer SDK uses to run management messages |
| asperaInfo | [AsperaInfo](#transfersdk-AsperaInfo) | repeated | Information about the running IBM Aspera binaries |
| licenseInfo | [LicenseInfo](#transfersdk-LicenseInfo) |  | Information about the IBM Aspera license |
| promiscuousMode | [bool](#bool) |  | Enable promiscuous mode for the transfer. If the transfer is started in promiscuous mode, sessions are discoverable by any user. Allowable values: true, false. |






<a name="transfersdk-InstanceInfoRequest"></a>

### InstanceInfoRequest
Requests data about the Transfer SDK service instance.






<a name="transfersdk-InstanceInfoResponse"></a>

### InstanceInfoResponse
Returns data about the Transfer SDK service instance.


| Field | Type | Label | Description |
| ----- | ---- | ----- | ----------- |
| apiVersion | [string](#string) |  | Version of the API |
| info | [InstanceInfo](#transfersdk-InstanceInfo) |  | Data about the Transfer SDK service instance |
| error | [Error](#transfersdk-Error) |  | Error that is returned |






<a name="transfersdk-LicenseInfo"></a>

### LicenseInfo
Information about the Aspera license


| Field | Type | Label | Description |
| ----- | ---- | ----- | ----------- |
| maxRate | [string](#string) |  | Maximum transfer rate enabled by the IBM Aspera license |
| accountNumber | [string](#string) |  | IBM Aspera customer account number |
| licenseNumber | [string](#string) |  | IBM Aspera license number |
| license | [string](#string) |  | Contents of the IBM Aspera license |






<a name="transfersdk-LockPersistentTransferRequest"></a>

### LockPersistentTransferRequest
Request to mark an existing persistent transfer as done


| Field | Type | Label | Description |
| ----- | ---- | ----- | ----------- |
| transferId | [string](#string) |  | UUID for the transfer, returned from the initial transfer request. Used for subsequent requests. |






<a name="transfersdk-LockPersistentTransferResponse"></a>

### LockPersistentTransferResponse
Response from the request to mark an existing persistent transfer as done


| Field | Type | Label | Description |
| ----- | ---- | ----- | ----------- |
| apiVersion | [string](#string) |  | Version of the API |
| transferId | [string](#string) |  | UUID for the transfer, returned from the initial transfer request. Used for subsequent requests. |
| error | [Error](#transfersdk-Error) |  | Error that is returned |






<a name="transfersdk-MultiSession"></a>

### MultiSession
MultiSession settings object. Specifies the configuration on how
the transfer fileset will be split so it is transferred in parallel
using multiple transfer processes.


| Field | Type | Label | Description |
| ----- | ---- | ----- | ----------- |
| enable | [bool](#bool) |  | Enable using multisession mode. |
| number_of_sessions | [int32](#int32) |  | Number of parallel processes to transfer the fileset. |
| hosts | [MultiSessionHosts](#transfersdk-MultiSessionHosts) |  | Settings for using different remote hosts for the multiple transfer processes. |
| file_splitting | [MultiSessionFileSplitting](#transfersdk-MultiSessionFileSplitting) |  | Settings for the minimum size required to partition a single file across multiple transfer processes. |
| bandwidth | [MultiSessionBandwidth](#transfersdk-MultiSessionBandwidth) |  | Settings for the minimum rate required to enable multisession. |






<a name="transfersdk-MultiSessionBandwidth"></a>

### MultiSessionBandwidth
Settings for the minimum rate required to enable multisession.


| Field | Type | Label | Description |
| ----- | ---- | ----- | ----------- |
| bandwidth_kpbs_threshold | [int32](#int32) |  | Minimum bandwidth rate in kilobits per second (kbps) required to enable multisession. |






<a name="transfersdk-MultiSessionFileSplitting"></a>

### MultiSessionFileSplitting
Settings for the minimum size required to partition a single file
across multiple transfer processes.


| Field | Type | Label | Description |
| ----- | ---- | ----- | ----------- |
| size_kb_threshold | [int32](#int32) |  | Minimum size in kilobytes (kb) required to partition a single file across multiple transfer processes. |






<a name="transfersdk-MultiSessionHosts"></a>

### MultiSessionHosts
Settings for using different remote hosts for the multiple
transfer processes.


| Field | Type | Label | Description |
| ----- | ---- | ----- | ----------- |
| usedns | [bool](#bool) |  | Use the different IP addresses associated with the specified remoteHost hostname as destinations for the different transfer processes. |
| hosts | [string](#string) | repeated | If not using DNS, specify a list of hosts to use for the different transfer processes. |






<a name="transfersdk-NodeAPIHeaderSpec"></a>

### NodeAPIHeaderSpec
Values for the Node API header. The Node API is used to initiate and manage Aspera transfers.


| Field | Type | Label | Description |
| ----- | ---- | ----- | ----------- |
| key | [string](#string) |  | Node API header key |
| value | [string](#string) |  | Value for Node API header key |






<a name="transfersdk-NodeAPISpec"></a>

### NodeAPISpec
Information for the call to the Node API, which initiates and manages Aspera transfers.


| Field | Type | Label | Description |
| ----- | ---- | ----- | ----------- |
| url | [string](#string) |  | URL for call to Node API |
| headers | [NodeAPIHeaderSpec](#transfersdk-NodeAPIHeaderSpec) | repeated | Headers for the call to the Node API |






<a name="transfersdk-Path"></a>

### Path
Information about the transfer path


| Field | Type | Label | Description |
| ----- | ---- | ----- | ----------- |
| source | [string](#string) |  | Source path for the transfer |
| destination | [string](#string) |  | Destination path for the transfer |






<a name="transfersdk-PathPattern"></a>

### PathPattern
Data pattern used in the transfer path


| Field | Type | Label | Description |
| ----- | ---- | ----- | ----------- |
| pattern | [string](#string) |  | Pattern, such as regex, used in the transfer path |






<a name="transfersdk-PeerCheckRequest"></a>

### PeerCheckRequest
Request for a peer check


| Field | Type | Label | Description |
| ----- | ---- | ----- | ----------- |
| transferSpec | [string](#string) |  | Configuration parameters for the request |






<a name="transfersdk-PeerCheckResponse"></a>

### PeerCheckResponse
Data returned from a peer check request


| Field | Type | Label | Description |
| ----- | ---- | ----- | ----------- |
| apiVersion | [string](#string) |  | Version of the API |
| reachable | [bool](#bool) |  | Peer node is reachable. Allowable values: true, false |
| error | [Error](#transfersdk-Error) |  | Error data returned from the peer check |






<a name="transfersdk-QueryTransferResponse"></a>

### QueryTransferResponse
Data returned a transfer query


| Field | Type | Label | Description |
| ----- | ---- | ----- | ----------- |
| apiVersion | [string](#string) |  | Version of the API |
| transferId | [string](#string) |  | UUID for the transfer returned from the initial transfer request, used for subsequent requests |
| title | [string](#string) |  | User-assigned title for the transfer |
| transferType | [TransferType](#transfersdk-TransferType) |  | Transfer type |
| status | [TransferStatus](#transfersdk-TransferStatus) |  | Transfer status |
| error | [Error](#transfersdk-Error) |  | Error message |
| transferInfo | [TransferInfo](#transfersdk-TransferInfo) |  | Returned information about the transfer |
| message | [string](#string) |  | Message string |






<a name="transfersdk-ReadStreamRequest"></a>

### ReadStreamRequest
Request to read data from the stream


| Field | Type | Label | Description |
| ----- | ---- | ----- | ----------- |
| transferId | [string](#string) |  | UUID for the transfer returned from the initial transfer request. Used for subsequent requests. |






<a name="transfersdk-ReadStreamResponse"></a>

### ReadStreamResponse
Data returned after reading data from the stream


| Field | Type | Label | Description |
| ----- | ---- | ----- | ----------- |
| apiVersion | [string](#string) |  | Version of the API |
| path | [string](#string) |  | Path where the stream is read |
| pathSize | [int64](#int64) |  | Size of the file or path that is received as a stream |
| chunk | [Chunk](#transfersdk-Chunk) |  | Byte array sent in the stream |
| error | [Error](#transfersdk-Error) |  | Error that is returned |






<a name="transfersdk-RegistrationFilter"></a>

### RegistrationFilter
Components for filtering specific events. A filter without any item is considered as a pass through filter (accepting all the events).


| Field | Type | Label | Description |
| ----- | ---- | ----- | ----------- |
| operator | [RegistrationFilterOperator](#transfersdk-RegistrationFilterOperator) |  | Operator applying to this filter set used to compose registration filter items. |
| eventType | [TransferEvent](#transfersdk-TransferEvent) | repeated | All transfer event types |
| transferId | [string](#string) | repeated | All UUIDs included in the transfer |
| cookie | [string](#string) | repeated | All cookies included in the transfer |
| tags64 | [string](#string) | repeated | All tags included in the transfer (base64 encoded) |
| direction | [string](#string) |  | Direction of transfer, either send (upload) or receive (download) |
| cookieRegex | [string](#string) |  | Regex match for cookie included in the transfer |
| transferType | [TransferType](#transfersdk-TransferType) | repeated | A set of Transfer types |
| transferStatus | [TransferStatus](#transfersdk-TransferStatus) | repeated | A set of Transfer status types |






<a name="transfersdk-RegistrationRequest"></a>

### RegistrationRequest
Request to filter specific events


| Field | Type | Label | Description |
| ----- | ---- | ----- | ----------- |
| transferId | [string](#string) | repeated | UUID for the transfer, returned from the initial transfer request. Used for subsequent requests. |
| filters | [RegistrationFilter](#transfersdk-RegistrationFilter) | repeated | The RegistrationFilter objects, specifying which filter to apply on events to monitor. The goal of filter is to narrow down the events monitoring to a subset of events. Filter items can be composed using an operator (AND/OR, default is OR). When multiple filters are registered, they are processed as composed with an OR operator. |






<a name="transfersdk-RetryStrategy"></a>

### RetryStrategy
RetryStrategy configures the components of the retry strategy.


| Field | Type | Label | Description |
| ----- | ---- | ----- | ----------- |
| basic | [BasicRetryStrategy](#transfersdk-BasicRetryStrategy) |  | Basic retry strategy |
| backoff | [ExponentialBackoffRetryStrategy](#transfersdk-ExponentialBackoffRetryStrategy) |  | Exponential retry strategy |






<a name="transfersdk-SSHSpec"></a>

### SSHSpec
SSH Configuration


| Field | Type | Label | Description |
| ----- | ---- | ----- | ----------- |
| ssh_port | [int64](#int64) |  | TCP port that initiates the transfer session. |
| remote_password | [string](#string) |  | Password for the remote user |
| remote_user | [string](#string) |  | Remote user&#39;s username |
| ssh_private_key | [string](#string) |  | Private key for SSH |
| ssh_private_key_passphrase | [string](#string) |  | Private key passphrase for SSH |
| ssh_fingerprint | [string](#string) |  | Public SSH key of the server |






<a name="transfersdk-Security"></a>

### Security
Security configuration


| Field | Type | Label | Description |
| ----- | ---- | ----- | ----------- |
| content_protection_password | [string](#string) |  | Password for encryption of transferred assets |
| remote_access_key | [string](#string) |  | Access key for a remote server |
| token | [string](#string) |  | Token to authenticate the transfer. For details see the &#39;Authentication and authorization&#39; section in the IBM Aspera High Speed Transfer Server admin guide. |
| cipher | [string](#string) |  | Cipher algorithm to apply during the transfer. Valid values are: aes-128, aes-192, aes-256, aes-128-cfb, aes-192-cfb, aes-256-cfb, aes-128-gcm, aes-192-gcm, aes-256-gcm, none |






<a name="transfersdk-SessionTransferInformation"></a>

### SessionTransferInformation
Returned information about a transfer session. There can be multiple transfer sessions for each transfer.


| Field | Type | Label | Description |
| ----- | ---- | ----- | ----------- |
| id | [string](#string) |  | Unique ID that the SDK assigns to a transfer session |
| sessionId | [string](#string) |  | Unique ID that FASP assigns to a transfer session |
| user | [string](#string) |  | Remote transfer user |
| clientUser | [string](#string) |  | Username of the user running the transfer client on the local machine |
| clientNodeId | [string](#string) |  | ID of the node for the transfer client on the local machine |
| clientClusterId | [string](#string) |  | If applicable, the ID of the cluster for high availability on the local machine |
| serverNodeId | [string](#string) |  | Node ID of the remote transfer server |
| serverClusterId | [string](#string) |  | If applicable, the ID of the cluster for high availability on the remote transfer server |
| clientIPAddress | [string](#string) |  | IP address for the client on the local machine |
| serverIPAddress | [string](#string) |  | IP address for the remote transfer server |
| port | [int64](#int64) |  | UDP port used by FASP |
| tcpPort | [int64](#int64) |  | TCP port used to initiate a connection with the Transfer SDK |
| status | [string](#string) |  | Status of the transfer session. Allowable values: initiated, passed, skipped, failed. |
| startTimeUsec | [int64](#int64) |  | Transfer start time, in microseconds |
| endTimeUsec | [int64](#int64) |  | Transfer end time, in microseconds |
| elapsedUsec | [int64](#int64) |  | Total time elapsed during the transfer, in microseconds |
| bytesTransferred | [int64](#int64) |  | Total bytes transferred |
| bytesWritten | [int64](#int64) |  | Total bytes written at the destination |
| bytesLost | [int64](#int64) |  | Total bytes lost during the transfer |
| filesCompleted | [int64](#int64) |  | Total number of files that transferred successfully to the destination |
| filesFailed | [int64](#int64) |  | Total number of files that failed to transfer successfully |
| filesSkipped | [int64](#int64) |  | Total number of files skipped during the transfer session |
| directoriesCompleted | [int64](#int64) |  | Total number of directories that transferred completely |
| targetRateKbps | [int64](#int64) |  | Target transfer rate (Kbps) |
| minRateKbps | [int64](#int64) |  | Minimum transfer rate (Kbps) |
| calcRateKbps | [int64](#int64) |  | Calculated transfer rate (Kbps) |
| networkDelayUsec | [int64](#int64) |  | Network delay (microseconds) |
| errorCode | [int64](#int64) |  | Error code returned for a failed transfer of files or folders |
| errorDesc | [string](#string) |  | Description of the error for a failed transfer of files or folders |
| manifestFilePath | [string](#string) |  | Path to the manifest file |
| sourcePathsScanExcluded | [int64](#int64) |  | Number of source paths excluded from the filesystem scan |
| sourcePathsScanIrregular | [int64](#int64) |  | Number of irregular source paths found in the filesystem scan |
| sourcePathsScanFailed | [int64](#int64) |  | Number of source paths in a failed filesystem scan |
| sourcePathsScanAttempted | [int64](#int64) |  | Number of source paths in a filesystem scan that was initiated |
| transfersSkipped | [int64](#int64) |  | Total number of transfers skipped, because, for example, the file already exists at the destination. |
| transfersPassed | [int64](#int64) |  | Total number of successful transfers |
| transfersFailed | [int64](#int64) |  | Total number of transfers with errors |
| transfersAttempted | [int64](#int64) |  | Total number of transfers initiated |
| cookie | [string](#string) |  | All cookies included in the transfer |
| direction | [string](#string) |  | Direction of transfer, either send (upload) or receive (download) |
| fileChecksumType | [string](#string) |  | Hash of the file checksum. Allowable values: HASH: sha-512,sha-384,sha-256,sha1,md5. (Default: none) |
| operation | [string](#string) |  | Indicates a transfer or just a bandwidth measurement. Allowable values: Transfer, BWMeasurement |
| tags | [string](#string) |  | Metatags in JSON format specified by --tags |
| argTransfersAttempted | [int64](#int64) |  | Total number of transfers initiated, where the data is provided as an argument |
| argTransfersPassed | [int64](#int64) |  | Number of successful transfers, where the data is provided as an argument |
| argTransfersSkipped | [int64](#int64) |  | Number of skipped transfers, where the data is provided as an argument |
| argTransfersFailed | [int64](#int64) |  | Number of failed transfers, where the data is provided as an argument |
| encryption | [string](#string) |  | If yes, use encryption. |
| adaptive | [string](#string) |  | Transfer policy. Allowable values: Adaptive, Fixed, High |
| remote | [string](#string) |  | If Yes, this process is acting as the server. If No, this process is acting as the client. |
| destination | [string](#string) |  | Destination path for files being transferred |
| priority | [int64](#int64) |  | Transfer priority (1: high | 2: regular) |
| transferId | [string](#string) |  | UUID for the transfer, returned from the initial transfer request. Used for subsequent requests. |
| rateCap | [int64](#int64) |  | Maximum rate for transfers, in kilobits per second |
| minRateCap | [int64](#int64) |  | Minimum target rate for transfers, in kilobits per second |
| policyCap | [string](#string) |  | Transfer policy that is allowed |
| rateLock | [string](#string) |  | If yes, lock the target transfer rate to the default value set on the server. If no, changing the target rate is allowed. |
| minRateLock | [string](#string) |  | If no, changing the minimum transfer rate--set on the server--is allowed. |
| policyLock | [string](#string) |  | If no, changing the transfer policy (priority)--set on the server--is allowed. |
| serverHostname | [string](#string) |  | Hostname for the transfer server |
| remoteAddress | [string](#string) |  | IP address for the remote transfer server |
| cipher | [string](#string) |  | Cipher for content protection |
| resumePolicy | [string](#string) |  | Policy for resuming a transfer after the transfer is paused |
| createPolicy | [int64](#int64) |  | Policy for creating the transfer |
| manifestPolicy | [string](#string) |  | Policy for application settings in the SDK |
| precalc | [string](#string) |  | Policy for precalculating job size |
| overwritePolicy | [string](#string) |  | Overwrite files at the destination with source files of the same name based on the policy: - always – Always overwrite the file. - never – Never overwrite the file. If the destination contains partial files that are older or the same as the source files and resume is enabled, the partial files resume transfer. Partial files with checksums or sizes that differ from the source files are not overwritten. - diff – Overwrite the file if it is different from the source, depending on the compare method (default is size). If the destination is object storage, diff has the same effect as always. If resume is not enabled, partial files are overwritten if they are different from the source, otherwise they are skipped. If resume is enabled, only partial files with different sizes or checksums from the source are overwritten; otherwise, files resume. - diff&#43;older – Overwrite the file if it is older and different from the source, depending on the compare method (default is size). If resume is not enabled, partial files are overwritten if they are older and different from the source, otherwise they are skipped. If resume is enabled, only partial files that are different and older than the source are overwritten, otherwise they are resumed. - older – Overwrite the file if its timestamp is older than the source timestamp.

If you set an overwrite policy of diff or diff&#43;older, difference is determined by the value set for resume_policy: &#34;none&#34; - the source and destination files are always considered different and the destination file is always overwritten &#34;attributes&#34; - the source and destination files are compared based on file attributes &#34;sparse_checksum&#34; - the source and destination files are compared based on sparse checksums, (currently file size) &#34;full_checksum&#34; - the source and destination files are compared based on full checksums |
| rttAutocorrect | [string](#string) |  | Round trip time autocorrection |
| timePolicy | [int64](#int64) |  | Total time allowed for the transfer |
| manifestInprogress | [string](#string) |  | Suffix of the manifest file while the transfer is running |
| filesEncrypt | [string](#string) |  | Specifies that the files are encrypted with user supplied password. Allowable values: yes, no. |
| filesDecrypt | [string](#string) |  | Specifies that the files are decrypted with user supplied password. Allowable values: yes, no. |
| datagramSize | [int64](#int64) |  | Sets the datagram size to be used by the sender |
| vLinkVersion | [int64](#int64) |  | Version of the aggregate bandwidth caps applied to transfer sessions |
| peerVLinkVersion | [int64](#int64) |  | At the peer IP address, version of the aggregate bandwidth caps applied to transfer sessions |
| vLinkLocalEnabled | [string](#string) |  | Vlkink is enabled on the local machine |
| vLinkRemoteEnabled | [string](#string) |  | Vlkink is enabled on the remote transfer server |
| readBlockSize | [int64](#int64) |  | The size of data to be read from the disk on the sender |
| writeBlockSize | [int64](#int64) |  | The size of data to be written to the disk on the receiver |
| clusterNumNodes | [int64](#int64) |  | Number of sessions used in a multi-session transfer |
| clusterNodeId | [int64](#int64) |  | The session index number in a multi-session transfer |
| moveRange | [string](#string) |  | Size of data to be transferred when a range transfer is specified |
| keepalive | [string](#string) |  | The session is running in persistent session mode |
| testLogin | [string](#string) |  | The session is attempting a login, only, without data transfer |
| useProxy | [string](#string) |  | Use the forward proxy for Aspera file transfers |
| rateControlAlgorithm | [string](#string) |  | Algorithm to adapt the transmission rate in response to varying conditions |
| pmtu | [int64](#int64) |  | Path maximum transmission unit (MTU) value |
| preTransferFiles | [int64](#int64) |  | Total number of files discovered at the source that can potentially be transferred |
| preTransferBytes | [int64](#int64) |  | Total number of bytes discovered at the source that can potentially be transferred |
| preTransferDirs | [int64](#int64) |  | Total number of directories discovered at the source that can potentially be transferred |
| preTransferSpecial | [int64](#int64) |  | Total number of special files discovered at the source that can potentially be transferred |
| sourcePathsScanCompleted | [int64](#int64) |  | Total number of source paths that are scanned |
| argScansAttempted | [int64](#int64) |  | Source arguments handled |
| argScansCompleted | [int64](#int64) |  | Source arguments completed |
| argFaspFileArgIndex | [int64](#int64) |  | Command line argument index that specified this file (if argument was a directory, many files can have the same FaspFileArgIndex). In persistent mode, the argument is constantly increasing. |
| dirCreatesAttempted | [int64](#int64) |  | Total number of attempts to create a destination directory. |
| dirCreatesFailed | [int64](#int64) |  | Total number of attempts to create a destination directory that failed. |
| dirCreatesPassed | [int64](#int64) |  | Total number of attempts to create a directory where the destination directory already existed or was successfully created |
| dirScansCompleted | [int64](#int64) |  | Total source directory scans completed |






<a name="transfersdk-StartTransferResponse"></a>

### StartTransferResponse
Data returned from the transfer request


| Field | Type | Label | Description |
| ----- | ---- | ----- | ----------- |
| apiVersion | [string](#string) |  | Version of the API |
| transferId | [string](#string) |  | UUID for the transfer returned from the initial transfer request, used for subsequent requests |
| title | [string](#string) |  | User-assigned title for the transfer |
| transferType | [TransferType](#transfersdk-TransferType) |  | Type of transfer |
| status | [TransferStatus](#transfersdk-TransferStatus) |  | Transfer status |
| error | [Error](#transfersdk-Error) |  | Error message for the transfer, if any |






<a name="transfersdk-StopInfo"></a>

### StopInfo
Query to find out if the transfer is stopped


| Field | Type | Label | Description |
| ----- | ---- | ----- | ----------- |
| transferId | [string](#string) |  | UUID for the transfer returned from the initial transfer request, used for subsequent requests |
| stopped | [bool](#bool) |  | Transfer is stopped. |
| error | [Error](#transfersdk-Error) |  | Error that is returned |






<a name="transfersdk-StopTransferRequest"></a>

### StopTransferRequest
Request to stop the transfer


| Field | Type | Label | Description |
| ----- | ---- | ----- | ----------- |
| transferId | [string](#string) | repeated | UUID for the transfer, returned from the initial transfer request. Used for subsequent requests. |
| delay | [int64](#int64) |  | Length of time to delay before stopping the transfer |






<a name="transfersdk-StopTransferResponse"></a>

### StopTransferResponse
Data returned from the request to stop the transfer


| Field | Type | Label | Description |
| ----- | ---- | ----- | ----------- |
| apiVersion | [string](#string) |  | API version |
| stopResult | [StopInfo](#transfersdk-StopInfo) | repeated | Data about the results of the StopTransferRequest |






<a name="transfersdk-Streaming"></a>

### Streaming
Configuration for streaming


| Field | Type | Label | Description |
| ----- | ---- | ----- | ----------- |
| chunk_size | [int64](#int64) |  | Size of the byte array sent in streaming request and returned in response for both send and receive. |
| local_memory | [int64](#int64) |  | Amount of memory available on the local machine |
| remote_memory | [int64](#int64) |  | Amount of memory available on the remote server |
| sparse_file | [bool](#bool) |  | Enable ascp4 to write sparse files to disk. This option prevents ascp4 from writing zero content to disk for sparse files; ascp4 writes a block to disk if even one bit is set in that block. If no bits are set in the block, ascp4 does not write the block (Default size of ascp4 blocks is 64 KB.) |
| compression | [Compression](#transfersdk-Compression) |  | Compression object containing a string. Compress file data inline. Allowable values: none, zlib, lz4. (Default: lz4). If set to zlib, the compression hint can be used to set the compression level. |






<a name="transfersdk-Tracking"></a>

### Tracking
Tracking parameters


| Field | Type | Label | Description |
| ----- | ---- | ----- | ----------- |
| cookie | [string](#string) |  | All cookies included in the transfer |
| tags | [string](#string) |  | All tags included in the transfer |
| tags64 | [string](#string) |  | All tags included in the transfer (base64 encoded) |






<a name="transfersdk-TransferConfig"></a>

### TransferConfig
Configuration elements for the transfer


| Field | Type | Label | Description |
| ----- | ---- | ----- | ----------- |
| retry | [RetryStrategy](#transfersdk-RetryStrategy) |  | Strategy that is defined for retrying the transfer. Optional. No retry if not set. |
| license | [string](#string) |  | Contents of a custom license file. Optional. License in the binary path is used if not set. |
| localLog | [string](#string) |  | Local log directory path. Optional. |
| remoteLog | [string](#string) |  | Remote log directory path. Optional. |
| logLevel | [sfixed32](#sfixed32) |  | Level of detail to return in the log. Allowable values: 0 (minimal log data), 1, 2 (most detailed log data). |






<a name="transfersdk-TransferInfo"></a>

### TransferInfo
Returned information about the transfer


| Field | Type | Label | Description |
| ----- | ---- | ----- | ----------- |
| averageRateKbps | [int64](#int64) |  | Average rate for the transfer, in kilobits per second |
| bytesLost | [int64](#int64) |  | Total bytes lost during the transfer |
| bytesTransferred | [int64](#int64) |  | Total bytes transferred |
| bytesWritten | [int64](#int64) |  | Total bytes written at the destination |
| directoriesCompleted | [int64](#int64) |  | Total directories that transferred completely |
| startTimeUsec | [int64](#int64) |  | Transfer start time, in microseconds |
| elapsedUsec | [int64](#int64) |  | Total time elapsed during the transfer, in microseconds |
| endTimeUsec | [int64](#int64) |  | Transfer end time, in microseconds |
| errorCode | [string](#string) |  | Error code for the transfer |
| errorDescription | [string](#string) |  | Description of error |
| filesCompleted | [int64](#int64) |  | Number of files that arrived successfully at the destination. |
| targetRateKbps | [int64](#int64) |  | Target transfer rate (in Kbps) |
| minRateKbps | [int64](#int64) |  | Minimum transfer rate (in Kbps) |
| argTransfersAttempted | [int64](#int64) |  | Total number of transfers initiated, where the data is provided as an argument. For example, for an attempted transfer of a folder that contains multiple files, the value is 1. |
| argTransfersPassed | [int64](#int64) |  | Total number of successful transfers, where the data is provided as an argument. For example, for a given transferred folder that contains multiple files, the value is 1. |
| argTransfersSkipped | [int64](#int64) |  | Total number of skipped transfers, where the data is provided as an argument. For example, for a skipped transfer of a folder that contains multiple files, the value is 1. |
| argTransfersFailed | [int64](#int64) |  | Number of failed transfers |
| fileChecksumType | [string](#string) |  | Hash of the file checksum. Allowable values: HASH: sha-512,sha-384,sha-256,sha1,md5. (Default: none) |
| cookie | [string](#string) |  | Application-specified string |
| direction | [string](#string) |  | Direction of transfer, either send (upload) or receive (download) |
| operation | [string](#string) |  | Indicates a transfer or a bandwidth measurement. Allowable values: Transfer, BWMeasurement |
| tags64 | [string](#string) |  | All tags to include in the transfer (base64 encoded) |






<a name="transfersdk-TransferInfoRequest"></a>

### TransferInfoRequest
Request for information about the transfer


| Field | Type | Label | Description |
| ----- | ---- | ----- | ----------- |
| transferId | [string](#string) |  | UUID for the transfer returned from the initial transfer request. Used for subsequent requests. |






<a name="transfersdk-TransferModificationRequest"></a>

### TransferModificationRequest
Request to modify the transfer


| Field | Type | Label | Description |
| ----- | ---- | ----- | ----------- |
| transferId | [string](#string) |  | UUID for the transfer, returned from the initial transfer request. Used for subsequent requests |
| transferSpec | [string](#string) |  | Defines the configuration parameters for the transfer |






<a name="transfersdk-TransferModificationResponse"></a>

### TransferModificationResponse
Data returned from the request to modify the transfer


| Field | Type | Label | Description |
| ----- | ---- | ----- | ----------- |
| apiVersion | [string](#string) |  | API version |
| transferId | [string](#string) |  | UUID for the transfer returned from the initial transfer request. Used for subsequent requests. |
| status | [TransferStatus](#transfersdk-TransferStatus) |  | Status of the transfer |
| error | [Error](#transfersdk-Error) |  | Error message, if any |






<a name="transfersdk-TransferPath"></a>

### TransferPath
Information about transfer paths


| Field | Type | Label | Description |
| ----- | ---- | ----- | ----------- |
| source | [string](#string) |  | Source path for files being transferred |
| destination | [string](#string) |  | Destination path for files being transferred |
| range | [TransferRange](#transfersdk-TransferRange) |  | Defines the range for a stream |






<a name="transfersdk-TransferPathRequest"></a>

### TransferPathRequest
Request for information about the transfer path


| Field | Type | Label | Description |
| ----- | ---- | ----- | ----------- |
| transferId | [string](#string) |  | UUID for the transfer, returned from the initial transfer request. Used for subsequent requests. |
| transferPath | [TransferPath](#transfersdk-TransferPath) | repeated | Information about transfer paths, both source and destination |






<a name="transfersdk-TransferPathResponse"></a>

### TransferPathResponse
Data returned from the request for information about the transfer path


| Field | Type | Label | Description |
| ----- | ---- | ----- | ----------- |
| apiVersion | [string](#string) |  | Version of the API |
| transferId | [string](#string) |  | UUID for the transfer returned from the initial transfer request, used for subsequent requests |
| error | [Error](#transfersdk-Error) |  | Error that is returned |






<a name="transfersdk-TransferRange"></a>

### TransferRange
Transfer range in a file or stream request


| Field | Type | Label | Description |
| ----- | ---- | ----- | ----------- |
| offset | [int64](#int64) |  | offset for the stream |
| length | [int64](#int64) |  | length of the stream |






<a name="transfersdk-TransferRequest"></a>

### TransferRequest
Parameters to submit to the transfer server


| Field | Type | Label | Description |
| ----- | ---- | ----- | ----------- |
| transferType | [TransferType](#transfersdk-TransferType) |  | Specify the type of transfer. Allowable values: UNKNOWN_TRANSFER_TYPE, FILE_REGULAR, FILE_PERSISTENT, URL_STREAM_TO_STREAM, FILE_TO_STREAM_DOWNLOAD, STREAM_TO_FILE_UPLOAD PERSISTENT_STREAM_UPLOAD |
| config | [TransferConfig](#transfersdk-TransferConfig) |  | Policies and permissions for the transfer |
| transferSpec | [string](#string) |  | Full configuration details for the transfer |






<a name="transfersdk-TransferResponse"></a>

### TransferResponse
Data returned from the transfer request


| Field | Type | Label | Description |
| ----- | ---- | ----- | ----------- |
| apiVersion | [string](#string) |  | Version of the API |
| transferId | [string](#string) |  | UID for the transfer returned from the initial transfer request. Used for subsequent requests |
| title | [string](#string) |  | User-assigned title of the transfer |
| transferType | [TransferType](#transfersdk-TransferType) |  | Transfer type |
| status | [TransferStatus](#transfersdk-TransferStatus) |  | Status of the transfer |
| error | [Error](#transfersdk-Error) |  | Error message for the transer |
| transferEvent | [TransferEvent](#transfersdk-TransferEvent) |  | Transfer event type |
| transferInfo | [TransferInfo](#transfersdk-TransferInfo) |  | Returned information about the transfer |
| message | [string](#string) |  | Message string |
| sessionInfo | [SessionTransferInformation](#transfersdk-SessionTransferInformation) |  | Information about a transfer session. There can be more than one transfer sessions for a given transfer. |
| fileInfo | [FileTransferInformation](#transfersdk-FileTransferInformation) |  | Information about the file transfer |






<a name="transfersdk-TransferSpecV1"></a>

### TransferSpecV1
The transfer specification (transferSpec) contains all components needed to initiate, monitor, and control transfers.


| Field | Type | Label | Description |
| ----- | ---- | ----- | ----------- |
| cipher | [string](#string) |  | Cipher for content protection |
| content_protection | [string](#string) |  | Enable client-side content protection (encryption-at-rest). For uploads, set to encrypt to transfer encrypted files and store them on the server with the extension &#34;.aspera-env&#34;. To download and decrypt encrypted files, set to decrypt. content_protection_password must be specified if this option is set. Values are : encrypt and decrypt |
| content_protection_password | [string](#string) |  | Password for encryption of transferred assets |
| cookie | [string](#string) |  | Application-specified string |
| create_dir | [bool](#bool) |  | Create a directory at the transfer destination |
| delete_before_transfer | [bool](#bool) |  | Before transfer, delete files that exist at the destination but not at the source. The source and destination arguments must be directories that have matching names. Objects on the destination that have the same name but different type or size as objects on the source are not deleted. |
| delete_source | [bool](#bool) |  | Delete the source directory after the assets are transferred |
| destination_root_id | [string](#string) |  | Root ID at the destination |
| direction | [string](#string) |  | Directon of transfer, whether send (upload) or receive (download) |
| exclude_newer_than | [string](#string) |  | Exclude files (but not directories) that are newer than a specific time from the transfer, based on when the file was last modified. Express in ISO 8601 format (for example, 2006-01-02T15:04:05Z) or as number of seconds elapsed since 00:00:00 UTC on 1 January 1970. |
| exclude_older_than | [string](#string) |  | Exclude files (but not directories) that are older than a specific time from the transfer, based on when the file was last modified. Express in ISO 8601 format (for example, 2006-01-02T15:04:05Z) or as number of seconds elapsed since 00:00:00 UTC on 1 January 1970. |
| fasp_port | [int64](#int64) |  | Port used for the transfer. (Default: 3301) |
| http_fallback | [bool](#bool) |  | Parameters to configure HTTP fallback |
| http_fallback_port | [int64](#int64) |  | Port used for HTTP fallback server |
| https_fallback_port | [int64](#int64) |  | Port used for HTTPS fallback |
| move_after_transfer | [string](#string) |  | Move source files under path the path after transfer success. |
| multi_session | [int64](#int64) |  | Split files across multiple ascp sessions to enable faster transfers. Allowable values: true, false. |
| multi_session_threshold | [int64](#int64) |  | Split files across multiple ascp sessions if their size is greater than or equal to the specified value. Default: 0 (no files are split). |
| overwrite | [string](#string) |  | Overwrite files at the destination with source files of the same name based on the policy: - always – Always overwrite the file. - never – Never overwrite the file. If the destination contains partial files that are older or the same as the source files and resume is enabled, the partial files resume transfer. Partial files with checksums or sizes that differ from the source files are not overwritten. - diff – Overwrite the file if it is different from the source, depending on the compare method (default is size). If the destination is object storage, diff has the same effect as always. If resume is not enabled, partial files are overwritten if they are different from the source, otherwise they are skipped. If resume is enabled, only partial files with different sizes or checksums from the source are overwritten; otherwise, files resume. - diff&#43;older – Overwrite the file if it is older and different from the source, depending on the compare method (default is size). If resume is not enabled, partial files are overwritten if they are older and different from the source, otherwise they are skipped. If resume is enabled, only partial files that are different and older than the source are overwritten, otherwise they are resumed. - older – Overwrite the file if its timestamp is older than the source timestamp.

If you set an overwrite policy of diff or diff&#43;older, difference is determined by the value set for resume_policy: &#34;none&#34; - the source and destination files are always considered different and the destination file is always overwritten &#34;attributes&#34; - the source and destination files are compared based on file attributes &#34;sparse_checksum&#34; - the source and destination files are compared based on sparse checksums, (currently file size) &#34;full_checksum&#34; - the source and destination files are compared based on full checksums |
| paths | [Path](#transfersdk-Path) | repeated | Path for the transfer |
| precalculate_job_size | [bool](#bool) |  | Restore the access time of the source file to the last access prior to transfer, which the source considers an access. |
| preserve_access_time | [bool](#bool) |  | Preserve the time the file was last accessed (read or write access) on the source. |
| preserve_creation_time | [bool](#bool) |  | Preserve timestamp for when a file is created |
| preserve_modification_time | [bool](#bool) |  | Preserve the time the object was last modified (write access) on the source. |
| preserve_times | [bool](#bool) |  | Preserve file timestamps |
| rate_policy | [string](#string) |  | The transfer rate policy to use when sharing bandwidth. Allowable values: high - When sharing bandwidth, transfer at twice the rate of a transfer using a fair policy. fair - (Default) Share bandwidth equally with other traffic. low - Use only unused bandwidth. fixed - Transfer at the target rate, regardless of the actual network capacity. Do not share bandwidth. Aspera recommends that you do not use this setting except under special circumstances, otherwise the destination storage can be damaged. |
| remote_access_key | [string](#string) |  | Access key for the remote server |
| remote_host | [string](#string) |  | Remote server used for the transfer |
| remote_password | [string](#string) |  | Password for the remote user |
| remote_user | [string](#string) |  | Remote user&#39;s username |
| remove_after_transfer | [bool](#bool) |  | Remove files at the source of the transfer after the transfer completes successfully |
| remove_empty_directories | [bool](#bool) |  | Remove empty subdirectories at the source of the transfer |
| resume_policy | [string](#string) |  | If a transfer is interrupted or fails to finish, this policy directs the transfer to resume without retransferring the files. Allowable values: &#34;none&#34; – always re-transfer the entire file &#34;attributes&#34; – compare file attributes and resume if they match, and re-transfer if they do not &#34;sparse_checksum&#34; – compare file attributes and the sparse file checksums; resume if they match, and re-transfer if they do not &#34;full_checksum&#34; – compare file attributes and the full file checksums; resume if they match, and re-transfer if they do not. |
| retry_duration | [int64](#int64) |  | Total time committed to retrying the transfer |
| source_root_id | [string](#string) |  | The file ID of the source root directory. Required if using bearer token authorization for the source node. |
| ssh_port | [int64](#int64) |  | TCP port that initiates the transfer session |
| ssh_private_key | [string](#string) |  | Private key for SSH |
| ssh_private_key_passphrase | [string](#string) |  | Private key passphrase for SSH |
| symlink_policy | [string](#string) |  | The method for processing symbolic links. Allowable values: follow, copy, copy&#43;force, skip |
| tags | [string](#string) |  | Tags to include in the transfer |
| tags64 | [string](#string) |  | Tags to include in the transfer (base64 encoded) |
| target_rate_cap_kbps | [int64](#int64) |  | Maximum target rate for incoming transfers, in kilobits per second. |
| target_rate_kbps | [int64](#int64) |  | Ideal transfer rate, in kilobits per second. There is no default value. |
| title | [string](#string) |  | Title of the transfer |
| token | [string](#string) |  | Token to authenticate the transfer. For details see the &#39;Authentication and authorization&#39; section in the IBM Aspera High Speed Transfer Server admin guide. |
| use_ascp4 | [bool](#bool) |  | Use ascp4 as the transfer engine. Allowable values: true, false. |
| fasp_proxy | [FASPProxy](#transfersdk-FASPProxy) |  | Proxy for communications between the remote server and the (local) client. |
| destination_root | [string](#string) |  | Destination root directory |
| source_root | [string](#string) |  | Source root directory |
| min_rate_cap_kbps | [int64](#int64) |  | The highest minimum rate that an incoming transfer can request, in kilobits per second. Client minimum rate requests that exceed the minimum rate cap are ignored. The default value of unlimited applies no cap to the minimum rate. (Default: 0) |
| lock_rate_policy | [bool](#bool) |  | If true, lock the rate policy to the default value Allowable values: true, false. |
| lock_target_rate_kbps | [bool](#bool) |  | If true, lock the target transfer rate to the default value set for target_rate_kbps. If false, users can adjust the transfer rate up to the value set for target_rate_cap_kbps. |
| lock_min_rate_kbps | [bool](#bool) |  | If true, lock the minimum transfer rate to the value set for min_rate_kbps. If false, users can adjust the transfer rate up to the value set for target_rate_cap_kbps. |
| src_base64 | [string](#string) |  | The folder name below which the directory structure is preserved (base64 encoded) |
| icos | [ICOSSpec](#transfersdk-ICOSSpec) |  | Configuration parameters for IBM Cloud Object Storage (ICOS) |
| node_api | [NodeAPISpec](#transfersdk-NodeAPISpec) |  | Configuration parameters for a call to the Node API |
| apply_local_docroot | [bool](#bool) |  | Apply the local docroot. This option is used to avoid entering object storage access credentials in the command line. Allowable values: true, false. |
| preserve_acls | [string](#string) |  | Preserve access control lists. Allowable values: none, native, metafile. |
| preserve_remote_acls | [string](#string) |  | Preserve remote access control lists. Allowable values: none, native, metafile |
| preserve_file_owner_uid | [bool](#bool) |  | Preserve the user ID for a file owner |
| preserve_file_owner_gid | [bool](#bool) |  | Preserve the group ID for a file owner |
| preserve_extended_attrs | [string](#string) |  | Preserve the extended attributes. Allowable values: none, native, metafile |
| preserve_remote_extended_attrs | [string](#string) |  | Preserve the extended attributes for a remote server. Allowable values: none, native, metafile |
| preserve_source_access_time | [bool](#bool) |  | Preserve the time logged for when the source file was accessed |
| remove_empty_source_dir | [bool](#bool) |  | Remove empty source subdirectories and remove the source directory itself, if empty |
| save_before_overwrite | [bool](#bool) |  | Rename the file instead of overwriting it. Allowable values: true, false. |
| skip_duplicate_check | [bool](#bool) |  | Don&#39;t check for duplicate files at the destination. Allowable values: true, false. |
| skip_special_files | [bool](#bool) |  | All assets other than files, directories and symbolic links are considered special. A transfer will fail if the user attempts to transfer special assets. If true, ascp skips special assets and proceeds with the transfer of all other assets. |






<a name="transfersdk-TransferSpecV2"></a>

### TransferSpecV2
The transfer specification (transferSpec) contains all components needed to initiate, monitor, and control transfers.
TransferSpecv2 allows you to construct a custom transfer specification. You only need to configure the modules (such as
Security or Transport) and parameters that are essential for your transfers.


| Field | Type | Label | Description |
| ----- | ---- | ----- | ----------- |
| session_initiation | [Initiation](#transfersdk-Initiation) |  | Parameters that define transfer initiation, including SSH |
| security | [Security](#transfersdk-Security) |  | Parameters that define security for the transfer |
| tracking | [Tracking](#transfersdk-Tracking) |  | Parameters that define asset tracking for the transfer, such as tags |
| file_system | [Filesystem](#transfersdk-Filesystem) |  | Parameters that define the handling of files and directories being transferred |
| transport | [Transport](#transfersdk-Transport) |  | Parameters that define rate policy and transfer rate |
| assets | [Assets](#transfersdk-Assets) |  | Parameters that define source and location for the transfer |
| direction | [string](#string) |  | Direction of the transfer, whether send (upload) or receive (download) |
| remote_host | [string](#string) |  | Name of the remote server |
| title | [string](#string) |  | Name assigned to the transfer |






<a name="transfersdk-Transport"></a>

### Transport
Values related to the transfer, including transfer policies


| Field | Type | Label | Description |
| ----- | ---- | ----- | ----------- |
| fasp_port | [int64](#int64) |  | Port used for the transfer. (Default: 3301) |
| http_fallback | [HTTPFallback](#transfersdk-HTTPFallback) |  | Fields for configuring HTTP fallback in the transferSpec v2 |
| fasp_proxy | [FASPProxy](#transfersdk-FASPProxy) |  | Fields for configuring the FASP proxy in the transferSpec v2. The FASP proxy coordinates communications between the remote server and the (local) client. |
| streaming | [Streaming](#transfersdk-Streaming) |  | Fields for configuring streaming in the transferSpec v2. |
| multi_session | [MultiSession](#transfersdk-MultiSession) |  | Split files across multiple ascp sessions to enable faster transfers. Allowable values: true, false. |
| multi_session_threshold | [int64](#int64) |  | Split files across multiple ascp sessions if their size is greater than or equal to the specified value. Default: 0 (no files are split). |
| rate_policy | [string](#string) |  | The transfer rate policy to use when sharing bandwidth. Allowable values: high - When sharing bandwidth, transfer at twice the rate of a transfer using a fair policy. fair - (Default) Share bandwidth equally with other traffic. low - Use only unused bandwidth. fixed - Transfer at the target rate, regardless of the actual network capacity. Do not share bandwidth. Aspera recommends that you do not use this setting except under special circumstances, otherwise the destination storage can be damaged. |
| lock_rate_policy | [bool](#bool) |  | If true, lock the rate policy to the default value Allowable values: true, false. |
| target_rate_cap_kbps | [int64](#int64) |  | Maximum target rate for incoming transfers, in kilobits per second. |
| target_rate_kbps | [int64](#int64) |  | Ideal transfer rate, in kilobits per second. There is no default value. |
| min_rate_cap_kbps | [int64](#int64) |  | The highest minimum rate that an incoming transfer can request, in kilobits per second. Client minimum rate requests that exceed the minimum rate cap are ignored. The default value of unlimited applies no cap to the minimum rate. (Default: unlimited) |
| min_rate_kbps | [int64](#int64) |  | Minimum transfer rate (in Kbps) |
| lock_target_rate_kbps | [bool](#bool) |  | If true, lock the target transfer rate to the default value set for target_rate_kbps. If false, users can adjust the transfer rate up to the value set for target_rate_cap_kbps. |
| lock_min_rate_kbps | [bool](#bool) |  | If true, lock the minimum transfer rate to the value set for min_rate_kbps. If false, users can adjust the transfer rate up to the value set for target_rate_cap_kbps. |
| use_ascp4 | [bool](#bool) |  | Use the ascp4 engine. Allowable values: true, false. |






<a name="transfersdk-ValidationRequest"></a>

### ValidationRequest
ValidationRequest submits the transfer specification (transferSpec) for validation and specifies a transfer type.


| Field | Type | Label | Description |
| ----- | ---- | ----- | ----------- |
| transferSpec | [string](#string) |  | The transfer specification to be validated |
| transferType | [TransferType](#transfersdk-TransferType) |  | The type of transfer |






<a name="transfersdk-ValidationResponse"></a>

### ValidationResponse
ValidationResponse contains the API version, the version of the transfer spec validator which is used, a boolean to indicate
if the validation is successful, and an error message, if any.


| Field | Type | Label | Description |
| ----- | ---- | ----- | ----------- |
| apiVersion | [string](#string) |  | Version of the API |
| valid | [bool](#bool) |  | Transfer specification is valid. Allowable values: true, false. |
| validatorVersion | [string](#string) |  | Version of transfer specification validator |
| unknownField | [string](#string) | repeated | Unkown field in the transfer specification |
| error | [Error](#transfersdk-Error) |  | Error that is returned |






<a name="transfersdk-WriteStreamChunkRequest"></a>

### WriteStreamChunkRequest
Response to the request to add data packets to the stream


| Field | Type | Label | Description |
| ----- | ---- | ----- | ----------- |
| transferId | [string](#string) |  | UUID for the transfer returned from the initial transfer request. Used for subsequentrequests |
| path | [string](#string) |  | Path where stream is written |
| range | [TransferRange](#transfersdk-TransferRange) |  | Range for the stream |
| chunk | [Chunk](#transfersdk-Chunk) |  | Byte array sent in the stream |






<a name="transfersdk-WriteStreamChunkResponse"></a>

### WriteStreamChunkResponse
Response to the request to write data to the stream


| Field | Type | Label | Description |
| ----- | ---- | ----- | ----------- |
| apiVersion | [string](#string) |  | API version |
| transferId | [string](#string) |  | UUID for the transfer returned from the initial transfer request. Used for subsequent requests. |
| error | [Error](#transfersdk-Error) |  | Error message, if any |






<a name="transfersdk-WriteStreamRequest"></a>

### WriteStreamRequest
Request to write data to the stream


| Field | Type | Label | Description |
| ----- | ---- | ----- | ----------- |
| transferId | [string](#string) |  | UUID for the transfer returned from the initial transfer request. Used for subsequent requests. |
| path | [string](#string) |  | Path to the stream |
| size | [int64](#int64) |  | Stream size |
| chunk | [Chunk](#transfersdk-Chunk) |  | Byte array sent in the stream |






<a name="transfersdk-WriteStreamResponse"></a>

### WriteStreamResponse
Response to the request to write data to the stream


| Field | Type | Label | Description |
| ----- | ---- | ----- | ----------- |
| apiVersion | [string](#string) |  | Version of the API |
| transferId | [string](#string) |  | UUID for the transfer returned from the initial transfer request, used for subsequent requests |
| error | [Error](#transfersdk-Error) |  | Error that is returned |





 


<a name="transfersdk-RegistrationFilterOperator"></a>

### RegistrationFilterOperator
Used to compose registration filter items.

| Name | Number | Description |
| ---- | ------ | ----------- |
| OR | 0 | Logical OR operator that returns the boolean value TRUE if either or both operands is TRUE and returns FALSE otherwise |
| AND | 1 | Logical AND operator that returns a value of TRUE if both its operands are TRUE, and FALSE otherwise |



<a name="transfersdk-TransferEvent"></a>

### TransferEvent
Transfer events

| Name | Number | Description |
| ---- | ------ | ----------- |
| UNKNOWN_EVENT | 0 | Transfer event can&#39;t be identified |
| SESSION_START | 1 | Transfer session started |
| SESSION_STOP | 2 | Transfer session stopped |
| SESSION_ERROR | 3 | Transfer session failed with an error |
| FILE_START | 4 | File transfer started |
| FILE_STOP | 5 | File transfer stopped |
| FILE_ERROR | 6 | File transfer failed with an error |
| ARG_STOP | 7 | ARG_STOP is a management message returned by FASP to indicate the completion of a transfer path provided as an argument to the transfer binary. |
| PROGRESS | 8 | Transfer in progress |
| CONNECTING | 9 | Transfer is connecting |
| RATE_MODIFICATION | 10 | Transfer rate modified during the transfer |
| FILE_SKIP | 11 | One or more files skipped during the transfer session |
| BANDWIDTH_MEASUREMENT | 12 | Bandwidth measurement assessed during the transfer |



<a name="transfersdk-TransferStatus"></a>

### TransferStatus
TransferStatus statuses a transfer can hold.

| Name | Number | Description |
| ---- | ------ | ----------- |
| UNKNOWN_STATUS | 0 | Transfer status is unknown |
| QUEUED | 1 | File or folder is queued for transfer |
| RUNNING | 2 | Transfer is running at the time of the query |
| COMPLETED | 3 | Transfer successfully completed |
| FAILED | 4 | Transfer failed |
| CANCELED | 5 | Transfer was canceled by the user |
| PAUSED | 6 | Transfer was paused by the user |
| ORPHANED | 7 | A file transferred without its parent folder |



<a name="transfersdk-TransferType"></a>

### TransferType
TransferType describes the possible transfer types.
When a user requests a new transfer, she can specify the type of transfer in the transferSpec.

| Name | Number | Description |
| ---- | ------ | ----------- |
| UNKNOWN_TRANSFER_TYPE | 0 | Unknown transfer type |
| FILE_REGULAR | 1 | File transfer using the paths you provide in the transferSpec |
| FILE_PERSISTENT | 2 | File transfer where you provide the source and destination paths while the transfer is in progress |
| URL_STREAM_TO_STREAM | 3 | Stream to stream session using the URI that you specify in the transferSpec |
| FILE_TO_STREAM_DOWNLOAD | 4 | Download a file as a stream at the destination. You must specify the size of the source file when starting the streaming of every file. Note: For this type of transfer, the supported values for the overwrite option are &#34;always&#34; or &#34;never&#34; in the transferSpec: any value other than &#34;always&#34; and &#34;never&#34; is defaulted to &#34;never&#34;. Resume option is not supported: any value for this option is defaulted to &#34;none&#34;. |
| STREAM_TO_FILE_UPLOAD | 5 | Upload a stream as a file at the destination. You must specify the total number of bytes to upload when starting the streaming of every file. Note: For this type of transfer, the supported values for the overwrite option are &#34;always&#34; or &#34;never&#34; in the transferSpec: any value other than &#34;always&#34; and &#34;never&#34; is defaulted to &#34;never&#34;. Resume option is not supported: any value for this option is defaulted to &#34;none&#34;. |
| PERSISTENT_STREAM_UPLOAD | 6 | Stream to file upload in a persistent session--meaning that you don&#39;t specify the stream size at the beginning of the transfer--using the URI specified in the transferSpec. |


 

 


<a name="transfersdk-TransferService"></a>

### TransferService
Transfer service definition. This service enables users to start, manage and monitor transfers.
You can also  get information about the transfer service settings and confirm the availability of
communication between the engine and a remote transfer server.

| Method Name | Request Type | Response Type | Description |
| ----------- | ------------ | ------------- | ------------|
| Validate | [ValidationRequest](#transfersdk-ValidationRequest) | [ValidationResponse](#transfersdk-ValidationResponse) | Validate accepts a transfer spec string and a transfer type, and returns the validation result. |
| StartTransfer | [TransferRequest](#transfersdk-TransferRequest) | [StartTransferResponse](#transfersdk-StartTransferResponse) | StartTransfer starts a new transfer and returns the transfer information required to manage and monitor the transfer. This request doesn&#39;t close until the transfer is terminated or the request is canceled by the client. |
| StartTransferWithMonitor | [TransferRequest](#transfersdk-TransferRequest) | [TransferResponse](#transfersdk-TransferResponse) stream | StartTransferWithMonitor starts a new transfer and streams back the transfer events. The request doesn&#39;t return immediately, as it continues streaming responses to the client until the transfer is terminated or the request is canceled by the client. |
| QueryTransfer | [TransferInfoRequest](#transfersdk-TransferInfoRequest) | [QueryTransferResponse](#transfersdk-QueryTransferResponse) | QueryTransfer requests transfer data. |
| ModifyTransfer | [TransferModificationRequest](#transfersdk-TransferModificationRequest) | [TransferModificationResponse](#transfersdk-TransferModificationResponse) | ModifyTransfer modifies an existing transfer. |
| AddTransferPaths | [TransferPathRequest](#transfersdk-TransferPathRequest) | [TransferPathResponse](#transfersdk-TransferPathResponse) | AddTransferPaths can be used with persistent transfer to add paths to an existing transfer. (type TransferType.FILE_PERSISTENT). |
| LockPersistentTransfer | [LockPersistentTransferRequest](#transfersdk-LockPersistentTransferRequest) | [LockPersistentTransferResponse](#transfersdk-LockPersistentTransferResponse) | LockPersistentTransfer, used with persistent transfer, marks an existing persistent transfer as done. Once the method is called, any subsequent call to AddTransferPaths results in an error. (type TransferType.FILE_PERSISTENT). |
| StopTransfer | [StopTransferRequest](#transfersdk-StopTransferRequest) | [StopTransferResponse](#transfersdk-StopTransferResponse) | StopTransfer stops a transfer. |
| MonitorTransfers | [RegistrationRequest](#transfersdk-RegistrationRequest) | [TransferResponse](#transfersdk-TransferResponse) stream | MonitorTransfers monitors transfers matching the defined filters and streams back the transfer events. The request doesn&#39;t return an immediate response because MonitorTransfers continues streaming responses to the client until the client cancels the request. |
| GetAPIVersion | [APIVersionRequest](#transfersdk-APIVersionRequest) | [APIVersionResponse](#transfersdk-APIVersionResponse) | GetAPIVersion gets the API version. |
| GetInfo | [InstanceInfoRequest](#transfersdk-InstanceInfoRequest) | [InstanceInfoResponse](#transfersdk-InstanceInfoResponse) | GetInfo gets data about the Transfer SDK service instance. |
| IsPeerReachable | [PeerCheckRequest](#transfersdk-PeerCheckRequest) | [PeerCheckResponse](#transfersdk-PeerCheckResponse) | IsPeerReachable confirms whether or not the peer endpoint is reachable. |
| WriteStreamChunk | [WriteStreamChunkRequest](#transfersdk-WriteStreamChunkRequest) stream | [WriteStreamChunkResponse](#transfersdk-WriteStreamChunkResponse) | WriteStreamChunk writes chunks of streaming data for the specified in-progress transfer of type PERSISTENT_STREAM_UPLOAD, at a specific offset. When StopTransfer is called on the transfer, subsequent calls to this function will fail. |
| WriteStream | [WriteStreamRequest](#transfersdk-WriteStreamRequest) stream | [WriteStreamResponse](#transfersdk-WriteStreamResponse) | WriteStream writes chunks of streaming data for the specified in-progress transfer of type STREAM_TO_FILE_UPLOAD. Once StopTransfer is called on the transfer, subsequent calls to this function will fail. |
| ReadStream | [ReadStreamRequest](#transfersdk-ReadStreamRequest) | [ReadStreamResponse](#transfersdk-ReadStreamResponse) stream | ReadStream reads chunks of streaming data from a specified in-progress transfer of type FILE_TO_STREAM_DOWNLOAD. Once StopTransfer is called on this transfer, subsequent calls to this function will fail. |

 



## Scalar Value Types

| .proto Type | Notes | C++ | Java | Python | Go | C# | PHP | Ruby |
| ----------- | ----- | --- | ---- | ------ | -- | -- | --- | ---- |
| <a name="double" /> double |  | double | double | float | float64 | double | float | Float |
| <a name="float" /> float |  | float | float | float | float32 | float | float | Float |
| <a name="int32" /> int32 | Uses variable-length encoding. Inefficient for encoding negative numbers – if your field is likely to have negative values, use sint32 instead. | int32 | int | int | int32 | int | integer | Bignum or Fixnum (as required) |
| <a name="int64" /> int64 | Uses variable-length encoding. Inefficient for encoding negative numbers – if your field is likely to have negative values, use sint64 instead. | int64 | long | int/long | int64 | long | integer/string | Bignum |
| <a name="uint32" /> uint32 | Uses variable-length encoding. | uint32 | int | int/long | uint32 | uint | integer | Bignum or Fixnum (as required) |
| <a name="uint64" /> uint64 | Uses variable-length encoding. | uint64 | long | int/long | uint64 | ulong | integer/string | Bignum or Fixnum (as required) |
| <a name="sint32" /> sint32 | Uses variable-length encoding. Signed int value. These more efficiently encode negative numbers than regular int32s. | int32 | int | int | int32 | int | integer | Bignum or Fixnum (as required) |
| <a name="sint64" /> sint64 | Uses variable-length encoding. Signed int value. These more efficiently encode negative numbers than regular int64s. | int64 | long | int/long | int64 | long | integer/string | Bignum |
| <a name="fixed32" /> fixed32 | Always four bytes. More efficient than uint32 if values are often greater than 2^28. | uint32 | int | int | uint32 | uint | integer | Bignum or Fixnum (as required) |
| <a name="fixed64" /> fixed64 | Always eight bytes. More efficient than uint64 if values are often greater than 2^56. | uint64 | long | int/long | uint64 | ulong | integer/string | Bignum |
| <a name="sfixed32" /> sfixed32 | Always four bytes. | int32 | int | int | int32 | int | integer | Bignum or Fixnum (as required) |
| <a name="sfixed64" /> sfixed64 | Always eight bytes. | int64 | long | int/long | int64 | long | integer/string | Bignum |
| <a name="bool" /> bool |  | bool | boolean | boolean | bool | bool | boolean | TrueClass/FalseClass |
| <a name="string" /> string | A string must always contain UTF-8 encoded or 7-bit ASCII text. | string | String | str/unicode | string | string | string | String (UTF-8) |
| <a name="bytes" /> bytes | May contain any arbitrary sequence of bytes. | string | ByteString | str | []byte | ByteString | string | String (ASCII-8BIT) |

