import grpc
import json

import transfer_pb2 as transfer_manager
import transfer_pb2_grpc as transfer_manager_grpc


# iterable stream of write stream requests
class FileSourceIterable:

    def __init__(self, transfer_id, file_path):
        self.count = 0
        self.content = "hello world"
        self.transfer_id = transfer_id
        self.file_path = file_path
        self.iterations = 20

    def __iter__(self):
        return self

    def __next__(self):
        self.count += 1
        if self.count > self.iterations:
            raise StopIteration
        return transfer_manager.WriteStreamRequest(transferId=self.transfer_id,
                                                   path=self.file_path,
                                                   size=self.size(),
                                                   chunk=transfer_manager.Chunk(contents=bytes(self.content, 'UTF-8')))

    # total size of the file you are streaming
    def size(self):
        return len(self.content) * self.iterations


def run():
    # create a connection to the transfer manager daemon
    client = transfer_manager_grpc.TransferServiceStub(grpc.insecure_channel('localhost:55002'))

    # create transfer spec
    transfer_spec = {
        "session_initiation": {
            "ssh": {
                "ssh_port": 33001,
                "remote_user": "aspera",
                "remote_password": "demoaspera"
            }
        },
        "direction": "send",

        "remote_host": "demo.asperasoft.com",
        "title": "primary",
        "assets": {
            "destination_root": "/Upload"
        }
    }
    transfer_spec = json.dumps(transfer_spec)

    # create a transfer request
    transfer_request = transfer_manager.TransferRequest(
        transferType=transfer_manager.STREAM_TO_FILE_UPLOAD,
        config=transfer_manager.TransferConfig(),
        transferSpec=transfer_spec)

    # send start transfer request to transfer manager daemon
    transfer_response = client.StartTransfer(transfer_request)
    transfer_id = transfer_response.transferId
    print("transfer started with id {0}".format(transfer_id))

    # write to the streams
    data_source = FileSourceIterable(transfer_id, 'stream_to_file_destination')
    write_stream_response = client.WriteStream(data_source)
    print(write_stream_response)

    # monitor transfer status
    for response in client.MonitorTransfers(
            transfer_manager.RegistrationRequest(
                filters=[transfer_manager.RegistrationFilter(transferId=[transfer_id])])):
        print(response)


if __name__ == '__main__':
    run()
