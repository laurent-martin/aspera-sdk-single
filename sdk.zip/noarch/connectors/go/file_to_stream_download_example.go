package main

import (
	"context"
	"fmt"
	"log"
	"time"

	"google.golang.org/grpc"
	"google.golang.org/grpc/status"
	"ibm.com/aspera/transfersdk/api/transfersdk"
)

// error handling in the grpc clients
// https://github.com/avinassh/grpc-errors

func main() {
	fmt.Println("FaspManager client ...")
	//create the API and  create a client
	opts := grpc.WithInsecure()
	cc, err := grpc.Dial("127.0.0.1:55002", opts)
	if err != nil {
		log.Fatal(err)
	}
	defer cc.Close()
	client := transfersdk.NewTransferServiceClient(cc)

	//A transfer_spec (the V1 which is widely used in Aspera products)
	//We are proposing a V2 to simplify the spec (refer to doc)
	transferSpec :=
		`
		{
			"paths": [
				{
					"source": "aspera-test-dir-small/10MB.1"
				},
				{
					"source": "aspera-test-dir-tiny/200KB.2"
				},
				{
					"source": "aspera-test-dir-tiny/200KB.3"
				}
			],
			"remote_host": "demo.asperasoft.com",
			"direction": "recv",
			"destination_root": "/tmp",
			"remote_user": "asperaweb",
			"ssh_port": 33001,
			"overwrite":"always",
			"remote_password": "demoaspera"
		}
	`

	ctx := context.Background()
	transferrequest := &transfersdk.TransferRequest{
		TransferSpec: transferSpec,
		Config: &transfersdk.TransferConfig{
			Retry: &transfersdk.RetryStrategy{},
		},
		TransferType: transfersdk.TransferType_FILE_TO_STREAM_DOWNLOAD,
	}
	transferresponse, err := client.StartTransfer(ctx, transferrequest)
	if err != nil {
		handleErr(err)
	}

	time.Sleep(10 * time.Second)

	log.Printf("TransferResponse: %v\n", transferresponse)
	transferid := transferresponse.GetTransferId()
	r := transfersdk.ReadStreamRequest{
		TransferId: transferid,
	}
	stream, err := client.ReadStream(ctx, &r)
	if err != nil {
		handleErr(err)
	}
	receiveFile(stream)
	if err != nil {
		handleErr(err)
	}
	log.Printf("WriteStreamRequest: %#v\n", r)
	// client.StopTransfer()
	stop := transfersdk.StopTransferRequest{
		TransferId: []string{transferid},
	}
	// time.Sleep(30 * time.Second)
	res, err := client.StopTransfer(ctx, &stop)
	if err != nil {
		handleErr(err)
	}
	log.Printf("StopTransfer: %#v\n", res)
}

func receiveFile(stream transfersdk.TransferService_ReadStreamClient) {
	var err error
	type readstruct struct {
		expected int64
		read     int64
	}
	reads := make(map[string]*readstruct, 0)
	for err == nil {
		var read *transfersdk.ReadStreamResponse
		read, err = stream.Recv()
		if err == nil {
			r, found := reads[read.Path]
			if found {
				r.read += int64(len(read.Chunk.Contents))
				fmt.Printf("Read file=%s expectedSize=%d readBytes=%d\n", read.Path, r.expected, r.read)
			} else {
				r := &readstruct{
					expected: read.PathSize,
					read:     int64(len(read.Chunk.Contents)),
				}
				reads[read.Path] = r
				fmt.Printf("Read file=%s expectedSize=%d readBytes=%d (NEW)\n", read.Path, r.expected, r.read)
			}
		}
	}
	fmt.Println("err = ", err)
}

func handleErr(err error) {
	if err != nil {
		// ouch!
		// lets print the gRPC error message
		// which is "Length of `Name` cannot be more than 10 characters"
		errStatus, _ := status.FromError(err)
		fmt.Println(errStatus.Message())
		// lets print the error code which is `INVALID_ARGUMENT`
		fmt.Println(errStatus.Code())
		panic(err)
	}
}
