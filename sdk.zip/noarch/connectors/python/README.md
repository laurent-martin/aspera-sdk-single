# Aspera Transfer SDK - Python Examples

Aspera Transfer SDK Library Files

    transfer_pb2.py
    transfer_pb2_grpc.py

### Requirements
- Python 3

### Setup
-     pip3 install -r requirements.txt

### Run
- In a separate window, start the transfer sdk daemon

      # from the aspera transfer sdk installation directory
      ./bin/asperatransferd

- Run the desired example

      python3 regular_file_example.py
