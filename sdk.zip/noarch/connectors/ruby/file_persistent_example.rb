# Grpc generated classes are assumed to be in the load path
$LOAD_PATH << '.'

require 'transfer_services_pb'
require 'json'
require_relative 'utils'

include Transfersdk

def main
  # create a connection to the faspmanager daemon
  client = TransferService::Stub.new('localhost:55002',
                                     :this_channel_is_insecure)

  # create transfer spec string
  transfer_spec = {
    session_initiation: {
      ssh: {
        ssh_port: 33001,
        remote_user: 'aspera',
        remote_password: 'demoaspera'
      }
    },
    direction: 'send',
    remote_host: 'demo.asperasoft.com',
    assets: {
      destination_root: '/Upload'
    }
  }.to_json

  # create a transfer request
  transfer_request = TransferRequest.new(
    transferType: TransferType::FILE_PERSISTENT, # transfer type (file/stream)
    config: TransferConfig.new(logLevel: 2), # transfer configuration
    transferSpec: transfer_spec) # transfer definition

  # send start transfer request to the transfer sdk daemon
  start_transfer_response = client.start_transfer(transfer_request)
  transfer_id = start_transfer_response.transferId
  puts "transfer started with id #{transfer_id}"

  # generate example file to transfer
  file_name = 'file'
  file_path = Helper.generate_source_file(file_name)

  # add file path to existing persistent transfer
  transfer_path_request = TransferPathRequest.new(
    transferId: transfer_id,
    transferPath: [
      TransferPath.new(
        source: file_path,
        destination: file_name)
    ]
  )
  client.add_transfer_paths(transfer_path_request) do |response|
    puts "add transfer path #{response}"
  end

  # monitor transfer until file has transferred
  monitor_transfer_request = RegistrationRequest.new(
    transferId: [transfer_id],
    filters: [
      RegistrationFilter.new(
        operator: RegistrationFilterOperator::OR
      )
    ]
  )
  client.monitor_transfers(monitor_transfer_request) do |transfer_info_response|
    puts "transfer info #{transfer_info_response}"

    # check for FILE_STOP message (FILE_STOP means the file has finished)
    transfer_event = transfer_info_response.transferEvent
    break if transfer_event == :FILE_STOP

    sleep 1
  end

  # lock the transfer
  lock_transfer_request = LockPersistentTransferRequest.new(
    transferId: transfer_id)
  client.lock_persistent_transfer(lock_transfer_request)
  puts 'lock persistent transfer'

  # monitor until persistent transfer has finished
  monitor_transfer_request = RegistrationRequest.new(transferId: [transfer_id])
  client.monitor_transfers(monitor_transfer_request) do |transfer_info_response|
    puts "transfer info #{transfer_info_response}"

    # check persistent transfer status in response, and exit if it's done
    status = transfer_info_response.status
    break if [:COMPLETED, :FAILED].include?(status)

    sleep 1
  end

  puts 'finished'
end

# program entry point
main if __FILE__ == $PROGRAM_NAME
