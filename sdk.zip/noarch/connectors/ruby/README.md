# Aspera Transfer SDK - Ruby Examples

Aspera Transfer SDK Library Files

        transfer_pb.rb
        transfer_services_pb.rb

### Requirements
- Ruby (tested with 2.7.1)
- Bundle (gem install bundler)
- grpc gem
- json gem

### Setup
    bundle install

### Run
- In a separate window, start the transfer sdk daemon

      # from the aspera transfer sdk installation directory
      ./bin/asperatransferd

- Run the desired example

      bundle exec ruby file_regular_download_example.rb
