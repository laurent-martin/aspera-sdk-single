# Grpc generated classes are assumed to be in the load path
$LOAD_PATH << '.'

require 'transfer_services_pb'

require_relative 'utils'

include Transfersdk

def main
  # create a connection to the faspmanager daemon
  client = TransferService::Stub.new('localhost:55002',
                                     :this_channel_is_insecure)

  # request api versions
  api_version_response = client.get_api_version(APIVersionRequest.new)
  puts "supported api versions #{api_version_response}"
end

# program entry point
main if __FILE__ == $PROGRAM_NAME
