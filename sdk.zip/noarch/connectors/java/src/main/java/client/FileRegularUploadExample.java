package client;

import ibm.aspera.transferservice.Transfer;
import ibm.aspera.transferservice.TransferServiceGrpc;
import io.grpc.ManagedChannelBuilder;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Iterator;

public class FileRegularUploadExample {

    public static void main(String... args) throws IOException {
        // create a connection to the transfer sdk daemon
        TransferServiceGrpc.TransferServiceBlockingStub client = TransferServiceGrpc.newBlockingStub(
                ManagedChannelBuilder.forAddress("localhost", 55002).usePlaintext().build());

        // (optional) check that the daemon is responding (get information about the daemon environment)
        // Transfer.InstanceInfoRequest instanceInfoRequest = Transfer.InstanceInfoRequest.newBuilder().build();
        // Transfer.InstanceInfoResponse instanceInfoResponse = client.getInfo(instanceInfoRequest);
        // System.out.println(String.format("instance info response %s", instanceInfoResponse));

        // generate example file to transfer
        String filePath = generateSourceFile();

        // create transfer spec string
        String transferSpec = "{\n" +
                "  \"session_initiation\": {\n" +
                "    \"ssh\": {\n" +
                "      \"ssh_port\": 33001,\n" +
                "      \"remote_user\": \"aspera\",\n" +
                "      \"remote_password\": \"demoaspera\"\n" +
                "    }\n" +
                "  },\n" +
                "  \"direction\": \"send\",\n" +
                "  \"remote_host\": \"demo.asperasoft.com\",\n" +
                "  \"title\": \"strategic\",\n" +
                "  \"assets\": {\n" +
                "    \"destination_root\": \"/Upload\",\n" +
                "    \"paths\": [\n" +
                "      {\n" +
                "        \"source\": \"" + filePath + "\"\n" +
                "      }\n" +
                "    ]\n" +
                "  }\n" +
                "}";

        // send start transfer request to transfer sdk daemon
        Transfer.StartTransferResponse transferResponse = client.startTransfer(Transfer.TransferRequest.newBuilder()
                .setTransferType(Transfer.TransferType.FILE_REGULAR)
                .setConfig(Transfer.TransferConfig.newBuilder().build())
                .setTransferSpec(transferSpec)
                .build());
        String transferId = transferResponse.getTransferId();
        System.out.println(String.format("transfer started with id %s", transferId));

        Iterator<Transfer.TransferResponse> monitorTransferResponse = client.monitorTransfers(
                Transfer.RegistrationRequest.newBuilder()
                        .addTransferId(transferId)
                        .addFilters(Transfer.RegistrationFilter.newBuilder()
                                .setOperator(Transfer.RegistrationFilterOperator.OR)
                                // .addTransferId(transferId)
                                .build())
                        .build());

        while (monitorTransferResponse.hasNext()) {
            Transfer.TransferResponse info = monitorTransferResponse.next();
            System.out.println("transfer info " + info);
            System.out.println("file info " + info.getFileInfo());
            System.out.println("transfer event " + info.getTransferEvent());
            if (info.getStatus() == Transfer.TransferStatus.FAILED ||
                    info.getStatus() == Transfer.TransferStatus.COMPLETED ||
                    info.getTransferEvent() == Transfer.TransferEvent.FILE_STOP) {
                System.out.println("upload finished " + info.getStatus().toString());
                break;
            }
        }
    }

    public static String generateSourceFile() throws IOException {
        File file = new File("file");
        FileWriter writer = new FileWriter(file);
        writer.write("Hello World!");
        writer.close();
        return file.getAbsolutePath();
    }
}
