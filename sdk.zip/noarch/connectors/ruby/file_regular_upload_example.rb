# frozen_string_literal: true
# Transfer Manager
# Ruby Client Example
# IBM Aspera

# Grpc generated classes are assumed to be in the load path
$LOAD_PATH << '.'
require 'transfer_services_pb'

require 'json'
require_relative 'utils'

include Transfersdk

def main
  # create a connection to the transfer manager daemon
  client = TransferService::Stub.new('localhost:55002',
                                     :this_channel_is_insecure)

  # generate example file to transfer
  file_path = Helper.generate_source_file('file')

  # create transfer spec string
  transfer_spec = {
    session_initiation: {
      ssh: {
        ssh_port: 33001,
        remote_user: 'aspera',
        remote_password: 'demoaspera'
      }
    },
    security: {
      cipher: 'aes-256'
    },
    direction: 'send',
    title: 'example',
    remote_host: 'demo.asperasoft.com',
    assets: {
      destination_root: '/Upload',
      paths: [
        {
          source: file_path
        }
      ]
    }
  }.to_json

  puts "transfer spec #{transfer_spec}"

  # create a transfer request
  transfer_request = TransferRequest.new(
    transferType: TransferType::FILE_REGULAR, # transfer type (file/stream)
    config: TransferConfig.new, # transfer configuration
    transferSpec: transfer_spec) # transfer definition

  # send start transfer request to the transfer manager daemon
  start_transfer_response = client.start_transfer(transfer_request)
  puts "start transfer response #{start_transfer_response}"
  transfer_id = start_transfer_response.transferId
  puts "transfer started with id #{transfer_id}"

  # monitor transfer status
  client.monitor_transfers(
    RegistrationRequest.new(transferId: [transfer_id],
                            filters: [
                              RegistrationFilter.new(
                                operator: RegistrationFilterOperator::OR,
                                eventType: [TransferEvent::FILE_STOP],
                                direction: 'Receive'),
                              RegistrationFilter.new(
                                operator: RegistrationFilterOperator::AND,
                                transferStatus: [TransferStatus::COMPLETED]
                              )
                            ])) do |response|
    puts "transfer info #{response}"

    # check transfer status in response, and exit if it's done
    status = response.status
    if [:FAILED, :COMPLETED].include?(status)
      puts "upload finished #{status}"
      break
    end
  end
end

main if __FILE__ == $PROGRAM_NAME
