package client;

import ibm.aspera.transferservice.Transfer;
import ibm.aspera.transferservice.TransferServiceGrpc;
import io.grpc.ManagedChannelBuilder;

import java.util.Iterator;

public class UrlStreamToStreamUploadExample {

    public static void main(String... args) {
        // create a connection to the transfer sdk daemon
        TransferServiceGrpc.TransferServiceBlockingStub client =
                TransferServiceGrpc.newBlockingStub(
                        ManagedChannelBuilder.forAddress(
                                "localhost", 55002)
                                .usePlaintext().build());

        // create transfer configuration
        String transferSpec = "{" +
                "  \"session_initiation\": {" +
                "    \"ssh\": {" +
                "      \"ssh_port\": 22," +
                "      \"remote_user\": \"root\"," +
                "      \"remote_password\": \"aspera\"" +
                "    }" +
                "  }," +
                "  \"direction\":\"send\"," +
                "  \"remote_host\":\"172.0.0.2\"," +
                "  \"assets\":{" +
                "    \"paths\":[" +
                "      {" +
                "        \"source\": \"tcp://127.0.0.1:33333\"," +
                "        \"destination\": \"tcp://127.0.0.1:33333\"" +
                "      }" +
                "    ]" +
                "  }" +
                "}";


        // start transfer
        Iterator<Transfer.TransferResponse> transferResponseIterator =
                client.startTransferWithMonitor(Transfer.TransferRequest.newBuilder()
                        .setTransferType(Transfer.TransferType.URL_STREAM_TO_STREAM)
                        .setConfig(Transfer.TransferConfig.newBuilder().build())
                        .setTransferSpec(transferSpec)
                        .build());

        // monitor transfer until it finishes
        transferResponseIterator.forEachRemaining(
                (pResponse) -> System.out.println("transfer response " + pResponse));
    }
}
