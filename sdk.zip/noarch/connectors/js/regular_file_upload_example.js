const protoLoader = require('@grpc/proto-loader');
const grpc = require('@grpc/grpc-js')
const fs = require('fs');
const path = require('path')

// load definition for the aspera transfer sdk package
const packageDefinition = protoLoader.loadSync(
    'transfer.proto',
    {
        keepCase: true,
        longs: String,
        enums: String,
        defaults: true,
        oneofs: true
    });
const transfersdk = grpc.loadPackageDefinition(packageDefinition).transfersdk;

// create a connection to the transfer manager daemon
let client = new transfersdk.TransferService('localhost:55002',
    grpc.credentials.createInsecure());

// create test file
let filePath = generateSourceFile()

// create transfer spec string
const transferSpec = {
    session_initiation: {
        ssh: {
            ssh_port: 33001,
            remote_user: 'aspera',
            remote_password: 'demoaspera'
        }
    },
    direction: 'send',
    remote_host: 'demo.asperasoft.com',
    assets: {
        destination_root: '/Upload',
        paths: [
            {
                source: filePath
            }
        ]
    }
}

const startTransferRequest = {
    transferType: 'FILE_REGULAR',
    transferSpec: JSON.stringify(transferSpec)
}

const eventStream = client.startTransferWithMonitor(
    startTransferRequest,
    function (err, _) {
        console.log("error starting transfer " + err)
    })
eventStream.on('data', function (data) {
    console.log("Transfer %d Mbps/%d Mbps %s %s %s",
        data.transferInfo.averageRateKbps / 1000,
        data.transferInfo.targetRateKbps / 1000,
        data.transferEvent, data.status,
        data.transferType);
})

function generateSourceFile() {
    let file = path.resolve("file")
    fs.writeFile(file, "Hello World!", function (err, f) {
    })
    return file
}
